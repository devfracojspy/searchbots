import sqlite3

def connect():
    return sqlite3.connect("gates.db")

def createDb():
    db = connect()

    try:
        db.executescript("PRAGMA journal_mode=WAL")
        db.executescript("""
--Armazenamento de gates--

CREATE TABLE IF NOT EXISTS gates(nome TEXT PRIMARY KEY NOT NULL, link TEXT NOT NULL, aprovada TEXT NOT NULL, reprovada TEXT NOT NULL);

--Armazenamento do gate atual--

CREATE TABLE IF NOT EXISTS gate_config(nome TEXT PRIMARY KEY NOT NULL, atual TEXT NOT NULL);""")
        db.executescript("INSERT INTO gate_config(nome, atual) VALUES ('1', 'None')")
        db.commit()
    except:
        return True
    finally:
        db.close()

class GateManager:
    def __init__(self) -> None:
        pass

    def add(nome, link, aprovada, reprovada):

        nome=nome.replace("'", "aspasSimples").replace('"', "aspasDuplas")
        link=link.replace("'", "aspasSimples").replace('"', "aspasDuplas")
        aprovada=aprovada.replace("'", "aspasSimples").replace('"', "aspasDuplas")
        reprovada=reprovada.replace("'", "aspasSimples").replace('"', "aspasDuplas")

        db = connect()

        try:
            db.executescript(f"INSERT INTO gates(nome, link, aprovada, reprovada) VALUES ('{nome}', '{link}', '{aprovada}', '{reprovada}');")
            db.commit()
            return True
        except Exception as e:
            print(e)
            return False
        finally:
            db.close()
    
    def remove(nome):
        db = connect()

        try:
            db.executescript(f"DELETE FROM gates WHERE nome='{nome}'")
            db.commit()
            return True
        except:
            return False
        finally:
            db.close()
    
    def get():
        db = connect()

        try:
            nome = db.execute("SELECT atual FROM gate_config WHERE nome='1' ").fetchone()[0]
            dados = db.execute(f"SELECT * FROM gates WHERE nome='{nome}'").fetchone()
            return dados
        except:
            return None
        finally:
            db.close()
    
    def list():
        db = connect()

        try:
            dados = db.execute(f"SELECT * FROM gates").fetchall()
            return dados
        except:
            return None
        finally:
            db.close()
    
    def set(nome):
        db = connect()

        try:
            db.executescript(f"UPDATE gate_config SET atual='{nome}'")
            return True
        except:
            return False
        finally:
            db.close()
    
    def getAtual():
        db = connect()

        try:
            nome = db.execute("SELECT atual FROM gate_config WHERE nome='1' ").fetchone()[0]
            return nome
        except:
            return None
        finally:
            db.close()