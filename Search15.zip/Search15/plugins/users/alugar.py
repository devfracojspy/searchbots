from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet

@Client.on_callback_query(filters.regex(r"^alugar$"))
async def btc(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[     
            [
				InlineKeyboardButton("Voltar", callback_data="start"),
            ],
        ]
    )
    await m.edit_message_text(
        f"""<a href=''>&#8204</a><b>⚠️ POLITICA DE REEMBOLSO ⚠️</b>

<b>⌛️ Atualmente o tempo médio de entrega de CC é de até 1 Minuto, como estamos recebendo muitas compras simultâneas, acabamos ficando com o tempo médio alto. Mas não se preocupe, não afetará na qualidade das CCs, nosso checker continua debitando!</b>

<b>❗️Envie apenas uma mensagem explicando sua situação, spam não fará com que seja respondido mais rapidamente.
- Prazo médio de resposta: 1 Hora.</b>

<b>🛒 Store: 
@afxstorebot</b>

<b>⚠️ Termos De Trocas:</b>

<b>🔗 Trocas via Bot:</b> <i>Nosso Bot usa checker debitado na troca, você pode pedir troca em até 20 minutos após realizar a compra!</i>

<b>🔗  Trocas manuais:</b> <i>Grave um vídeo/Print onde é visível o número do cartão, horário e erro. Aceitamos testes apenas gpay, via site.</i>

<b>📣 @SearchCanal</b>
<b>🔔 @afxtrem7suporte</b>""",
        reply_markup=kb,
	)