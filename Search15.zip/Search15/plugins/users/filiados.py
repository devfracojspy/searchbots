from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save
from utils import get_info_wallet

import datetime
from typing import Union
import asyncio

@Client.on_callback_query(filters.regex(r"^filiados$"))
async def gift(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[            
             [
				         InlineKeyboardButton("Resgate", url="https://t.me/afxtrem7suporte"),
				     ],
		      	 [
				         InlineKeyboardButton("🔙 Voltar", callback_data="user_info"),
             ],
        ]
    )
    link = f"https://t.me/{c.me.username}?start={m.from_user.id}"
    await m.edit_message_text(
        f"""<a href='https://i.ibb.co/y8rHFf5/7c2b6c15-1100-4de7-823f-be5a896125ba.jpg'>&#8204</a>Indique Amigos e Ganhe Recompensas no Pix 💰

<b>ℹ️ Como funciona?</b>

<b>📌 Compartilhe seu link de indicação e ganhe 20% dos valores carregados no site por seus indicados, saques via pix.</b>

<b>💰 Resgate no privado.</b>

<b>📎 Indicador:</b> <code>Não afiliado</code>
<b>🖇 Indicados:</b> <code>0</code>

<b>🔗 Seu Link:</b>
<code>{link}</code></b>
""",
        reply_markup=kb,
	)