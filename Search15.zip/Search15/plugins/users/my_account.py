from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

import datetime
from database import cur, save, db
from utils import get_info_wallet
from typing import Union
from config import DONO
import asyncio
import io
import sqlite3 

@Client.on_callback_query(filters.regex(r"^user_info$"))
async def user_info(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    username = m.from_user.username

    is_admin = user_id in DONO
    admin_status = "Sim" if is_admin else "Não"

    total_aux = cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", [user_id]).fetchone()[0]
    total_full = cur.execute("SELECT COUNT(*) FROM cards_sold_full WHERE owner = ?", [user_id]).fetchone()[0]
    total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]
    total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

    hora_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    hora_atual_str = hora_atual.strftime('%H:%M:%S')

    data_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    data_atual_str = data_atual.strftime('%d/%m/%Y')
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
                        [
                InlineKeyboardButton(
                                    '💠 Recargas Pix', callback_data='historypix'),                   
             ],
             [
                InlineKeyboardButton(
                                    '💳 Histórico CCs', callback_data='history'),   
             ],
             [ 
                InlineKeyboardButton("⚙️ Desenvolvedor", callback_data="termos"), 
             ],
             [
                 InlineKeyboardButton("🔙 Voltar", callback_data="start"),
             ],

        ]
    )
    link = f"https://t.me/{c.me.username}?start={m.from_user.id}"
    await m.edit_message_text(
        f"""‌<a href='https://i.ibb.co/QKHXCwq/679fd09c-0e0c-4ce6-b83c-949764e6fdd4.jpg'>&#8204</a><b>ℹ️ Suas informações dados abaixo:</b>

<b>👤 Nome:</b> <code>{m.from_user.first_name}</code>
<b>👥 User:</b> <code>@{username}</code>
<b>🆔 ID:</b> <code>{user_id}</code>
<b>📅 Data:</b> <code>{data_atual_str}</code>
<b>⏰ Horas:</b> <code>{hora_atual_str}</code>
<b>👮‍♀️ Admin: {admin_status}</b>
<b>💰 Saldo: {total_balance}</b>\n<b> 
<b>💠 Recargas com pix's:</b> <code>{total_recargas}</code>
<b>💳 Cartões comprados:</b> <code>{total_full}</code>

<i>Para ver seu histórico completo de recargas, cartões comprados, clica em um dos botões abaixo!</i>
""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buy_history$"))
async def buy_history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<b>Não há nenhuma compra nos registros.</b>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([i for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards])

    await m.edit_message_text(
        f"""<b>🛒 Histórico de compras</b>
<i>- Histórico de 50 últimas compras.</i>

{cards_txt}""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^swap_info$"))
async def swap_info(c: Client, m: CallbackQuery):
    await m.message.delete()

    cpf = await m.message.ask(
        "<b>👤 CPF da lara (válido) da lara que irá pagar</b>",
        reply_markup=ForceReply(),
        timeout=120,
    )
    name = await m.message.ask(
        "<b>👤 Nome completo do pagador</b>", reply_markup=ForceReply(), timeout=120
    )
    email = await m.message.ask(
        "<b>📧 E-mail</b>", reply_markup=ForceReply(), timeout=120
    )
    cpf, name, email = cpf.text, name.text, email.text
    cur.execute(
        "UPDATE users SET cpf = ?, name = ?, email = ?  WHERE id = ?",
        [cpf, name, email, m.from_user.id],
    )
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="start"),
            ]
        ]
    )
    await m.message.reply_text(
        "<b> Seus dados foram alterados com sucesso.</b>", reply_markup=kb
    )

@Client.on_callback_query(filters.regex(r"^delconta$"))
async def delconta(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    "✔️ Sim", callback_data="EXCLUIR"
                ),
            ],
            [InlineKeyboardButton("🔙 Voltar", callback_data="user_info")],
        ]
	)

    await m.edit_message_text(
        f"""<b>⚠️ Tem certeza que deseja excluir a conta? Todas as suas compras, recargas, indicados relacionados e saldo serão excluidos! Caso confirme, não será possível voltar atrás.</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^EXCLUIR$"))
async def excluir_conta(c: Client, m: CallbackQuery):

    # Atualiza os dados da conta do usuário para os valores padrão
    cur.execute(
        "UPDATE users SET balance = 0,  balance_diamonds = 0, agreed_tos = 0, last_bought = NULL, is_action_pending = 0, cpf = NULL, name = NULL, email = NULL WHERE id = ?",
        [m.from_user.id],
    )
    db.commit()

    await m.answer("⚠️ Sua Conta Foi Encerrada!")

    # Exibe uma mensagem para o usuário indicando o encerramento da conta
    await m.edit_message_text(f"""<b>🗑  Excluido com Sucesso<b>
<b>🗣 Usuario : {m.from_user.first_name}
📋 Id : {m.from_user.id} <b>
""")