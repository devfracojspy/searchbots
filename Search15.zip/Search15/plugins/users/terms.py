from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet

@Client.on_callback_query(filters.regex(r"^termos$"))
async def btc(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[     
            [
				InlineKeyboardButton("💵 Obter um bot", url="https://t.me/afxtrem7x"),
            ],
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="start"),
            ],
        ]
    )
    await m.edit_message_text(
        f"""<a href=''>&#8204</a><b>⚙️ Desenvolvimento do bot.</b> <code>(Search 1.0.0)</code>

<b>💡 Ficha técnica do bot!</b>

<b>- Owner: @afxtrem7x</b>
<b>- Versão:</b> <code>1.0.0 (Search) (13/01/2025)</code>
<b>- Canal: @searchcanal</b>
""",
        reply_markup=kb,
	)