import asyncio
import re
import time
import qrcode
from typing import Union
from asyncio.exceptions import TimeoutError
import html

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    User,
)

from config import PRIVADO, PUBLICO, NOTIFY
from database import cur, save
from payments import (
    AUTO_PAYMENTS,
    Gerencianet,
    GerencianetCredentials,
    Juno,
    JunoCredentials,
    MercadoPago,
    PagBank,
    PagBankCredentials,
    Asaas,
    OpenPix,
    EasyPix,
    SampaBank    
)

from utils import (
    create_mention,
    get_support_user,
    insert_sold_balance,
    lock_user_buy,
    notify_add_balance
)

def delete_old_qrcodes():
    qrcode_folder = "qrcode"
    current_time = time.time()

    for filename in os.listdir(qrcode_folder):
        filepath = os.path.join(qrcode_folder, filename)
        if os.path.isfile(filepath):
            creation_time = os.path.getctime(filepath)
            if current_time - creation_time > 120:  # 2 minutes in seconds
                os.remove(filepath)

def cpf_validate(numbers) -> bool:
    cpf = [int(char) for char in numbers if char.isdigit()]
    if len(cpf) != 11:
        return False
    if cpf == cpf[::-1]:
        return False
    for i in range(9, 11):
        value = sum((cpf[num] * ((i + 1) - num) for num in range(0, i)))
        digit = ((value * 10) % 11) % 10
        if digit != cpf[i]:
            return False
    return True

@lock_user_buy
async def verify_pay(
    c: Client,
    m: Message | CallbackQuery,
    objeto: Juno | MercadoPago | PagBank | Gerencianet | EasyPix,
    value: float,
    user_id: int | str,
    qr_message,
    mention,
    send: Message,  # Adicione o argumento 'send' aqui
):
    refer_bonus = (value / 100) * 5
    vl = value

    bns = cur.execute(
        "SELECT bonus_value, min_value FROM values_config WHERE transaction_type='auto'"
    ).fetchone()
    value += (
        round(((bns[0] / 100) * value))
        if bns is not None and value >= bns[1] and bns[0] > 0
        else 0
    )

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text='menu', callback_data='start')]
        ]
    )

    start_time = time.time()

    mult = (
        6 if objeto.c in ['PagBank', 'GerenciaNet', 'Juno', 'Asaas']
        else 30 if objeto.c == "MercadoPago"
        else 15
    )

    while time.time() - start_time < (
        mult * 60
    ):  # Esperando por 6 minutos, vai que né...
        rt = await objeto.verify()
        if rt == 'PAGO':
            saldobonus1 = cur.execute("SELECT valordobro FROM dobrosaldo").fetchone()[0]
            saldobonus = float(saldobonus1)
            saldobonus = value*saldobonus/100
            saldodobro = value + saldobonus
            refer, username, name = cur.execute(
                "SELECT refer, username, name_user FROM users WHERE id = ?",
                [objeto.user_id],
            ).fetchone()

            cur.execute(
                "UPDATE users SET balance = round(balance + ?, 2) WHERE id = ?",
                [saldodobro, objeto.user_id],
            )

            me = await c.get_me()
            notify = notify_add_balance(objeto.user_id, vl, me.id, me.username)

            try:
                await send.edit_text(
                    '<b>✅ O pagamento foi concluído e seu saldo foi adicionado à sua conta.</b>',
                    reply_markup=kb,
                )
            except BadRequest as e:
                print("Erro ao editar a mensagem:", e)

            await qr_message.delete()

            user = User(id=objeto.user_id, first_name=name, username=username)
            mention = create_mention(user)

            insert_sold_balance(value, objeto.user_id, 'auto')
            await c.send_message(
                PUBLICO,
                f'💰 {mention} Adicionou <b>R${vl}</b> de saldo',
            ) if objeto.c != "Pagbank" else None

            #await c.send_message(
            #    chat_id=NOTIFY,
            #    text=notify
            #) if objeto.c != "Pagbank" else None

            if refer:
                cur.execute(
                    'UPDATE users SET balance = round(balance + ?, 2) WHERE id = ?',
                    [refer_bonus, refer],
                )

                mention = create_mention(user, with_id=False)

                await c.send_message(
                    refer,
                    f'💰 Seu referenciado "{mention}" adicionou saldo no bot e você recebeu {refer_bonus} saldo.',
                )
            save()

            return

        await asyncio.sleep(2)

    if objeto.c in ['PagBank', 'GerenciaNet']:
        await objeto.hc.aclose()

    try:
        await m.edit_text(
            '<b>Nenhum depósito foi feito em 5 minutos, adição de saldo cancelada.</b>',
            reply_markup=kb,
        )
    except MessageIdInvalid:
        # Se o ID da mensagem for inválido, envie uma nova mensagem
        await c.send_message(m.chat.id, "O tempo expirou e o pagamento não foi recebido.")

    await qr_message.delete()

    name, username = cur.execute(
        'SELECT name_user, username FROM users WHERE id = ?', [objeto.user_id]
    ).fetchone()
    user = User(id=objeto.user_id, first_name=name, username=username)
    mention = create_mention(user)

    txt_info_user = f"""O usuário {mention}
solicitou pix automatico e não pagou.
"""
    return await c.send_message(PRIVADO, txt_info_user)

@Client.on_message(filters.command(['pix', 'recarga', 'saldo']))
@Client.on_callback_query(filters.regex(r'^add_balance_auto$'))
async def auto_pay(c: Client, m: Union[CallbackQuery, Message]):
    select_pay = cur.execute('SELECT pay_auto FROM bot_config').fetchone()[0]

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='🔙 Voltar', callback_data='add_balance'
                )
            ]
        ]
    )

    if not select_pay:
        if isinstance(m, CallbackQuery):
            return await m.answer(
                'Pix automático desativado, use o pix manual.', show_alert=True
            )
        else:
            return m.reply_text(
                'Pix automático desativado, use o pix manual.', reply_markup=kb
            )

    value = 0

    min_value = cur.execute('SELECT auto FROM add_balance').fetchone()[0]
    max_value = 200

    if isinstance(m, CallbackQuery):
        await m.message.delete()

        try:
            cob = await m.message.ask(
                f'<b>Digite o valor para ser cobrado (mínimo {min_value}), ex.: 32 ou 32.00:</b>',
                filters = filters.regex(r'^\d+(\.\d{2})?$'),
                reply_markup=ForceReply(),
                timeout=120,
            )
            value = float(cob.text)
        except TimeoutError:
            return await c.send_message(PRIVADO, "Usuario {} não digitou o valor para a cobrança".format(
                m.from_user.mention)
                                        )

        if value < min_value:
            return await m.message.reply_text(
                f'O valor deve ser maior ou igual a {min_value}.',
                reply_markup=kb,
            )

        elif value > max_value:
            return await m.message.reply_text(
                f'O valor deve ser menor ou igual a {max_value}.',
                reply_markup=kb,
            )

    elif isinstance(m, Message):
        if len(m.command) == 1:
            return await m.reply_text(
                '<b>Digite com um valor. ex: /pix 20</b>', reply_markup=kb
            )

        value = float(re.search(r'(?P<valor>\d+)', m.command[1])['valor'])

        if not value:
            return await c.send_message(PRIVADO, "Usuario {} não digitou o valor para a cobrança".format(
                m.from_user.mention)
                                        )

        if value < min_value:
            return await m.reply_text(
                f'O valor deve ser maior ou igual a {min_value}.',
                reply_markup=kb,
            )

        elif value > max_value:
            return await m.reply_text(
                f'O valor deve ser menor ou igual a {max_value}.',
                reply_markup=kb,
            )
    mm = m.message if isinstance(m, CallbackQuery) else m

    dados = cur.execute(
        'SELECT cpf, name, email FROM users  WHERE id = ?', [m.from_user.id]
    ).fetchone()

    pay_not_instance: Union[Gerencianet, MercadoPago, PagBank] = AUTO_PAYMENTS[
        select_pay
    ]

    pay, qr = '', ''
    '''''
    if None in (dados[0], dados[2]):
        cpf, full_name = '0', '0'
        await mm.reply_text(
            'Você não possui dados cadastrados, por favor responda o formulario a seguir.\n'
            'É importante que os dados forcecidos sejam <b>os mesmos do pagador</b> para verificar o pagamento, caso contrário o mesmo não será creditado.\n'
            'Caso precise alterar os dados posteriormente, use a opção "<b>Alterar dados Pix</b>", localizado em "<b>Minha conta</b>".',
        )
        await asyncio.sleep(1.5)
        
        cpf = ''
        for _ in range(3):
            cpf = await mm.ask(
                '<b>👤 CPF da lara (válido) da lara que irá pagar:</b>',
                reply_markup=ForceReply(),
                filters=filters.regex(r'^\d+(\.\d{2})?$'),
                timeout=120,
            )
            if cpf_validate(cpf.text):
                break

        if not cpf_validate(cpf.text):
            return

        cpf, full_name, email = (cpf.text, "aristides jose de abreu", "Asdasfasfasd@gmail.com")
        cpf.replace(".","").replace("-","").replace(" ","")
        cur.execute(
            """UPDATE users SET cpf = ?, name = ?, email = ? WHERE id = ?""",
            [cpf, full_name, email, m.from_user.id],
        )
        save()

    else:
        cpf, full_name, email = dados
        if dados == None:
            cpf, full_name, email = 1, 1, 1'''''

    cpf, full_name, email = 1, 1, 1
    if select_pay == 'mercado pago':
        app_user = cur.execute(
            'SELECT client_secret FROM tokens WHERE type_token= ?',
            [select_pay],
        ).fetchone()[0]
        pay: Union[Gerencianet, MercadoPago, Asaas] = pay_not_instance(
            access_token=app_user
        )
        resp = await pay.create_payment(
            value=value,
            email=email,
            full_name=full_name,
            cpf=cpf,
            user_id=m.from_user.id,
        )
        qr = resp['copy_paste']

    elif select_pay == "easy":
        pay: EasyPix = EasyPix()
        qr = await pay.create_payment(value=value, uid=m.from_user.id, cpf=cpf)

    elif select_pay == "sampa":
        pay = SampaBank()
        qr = await pay.create_payment(value=value, uid=m.from_user.id)

    elif select_pay == 'gerencia net':
        client_id, client_secret, name_cert_pem, key = cur.execute(
            'SELECT client_id, client_secret, name_cert_pem, key_pix FROM tokens WHERE type_token= ?',
            [select_pay],
        ).fetchone()

        objeto = GerencianetCredentials(
            client_id=client_id,
            client_secret=client_secret,
            key=key,
            cert=name_cert_pem,
        )
        pay = pay_not_instance(objeto)
        resp = await pay.create_payment(
            value=value,
            time=330,
            cpf=cpf,
            name=full_name,
            user_id=m.from_user.id,
        )
        qr = resp.get('qrcode')

    elif select_pay == 'pagbank':
        client_id, client_secret, path_pem, path_key, key = cur.execute(
            'SELECT client_id, client_secret, name_cert_pem, name_cert_key, key_pix FROM tokens WHERE type_token= ?',
            [select_pay],
        ).fetchone()

        objeto = PagBankCredentials(
            client_id, client_secret, key, path_pem, path_key
        )

        await objeto.gerar_tk()

        pay = pay_not_instance(objeto)
        resp = await pay.create_payment(
            value=value,
            time=330,
            cpf=cpf,
            name=full_name,
            user_id=m.from_user.id,
        )
        qr = resp['pixCopiaECola']

    elif select_pay == 'juno':
        client_id, client_secret, key_pix, priv_token = cur.execute(
            'SELECT client_id, client_secret, key_pix, bearer_tk FROM tokens WHERE type_token= ?',
            [select_pay],
        ).fetchone()

        objeto = JunoCredentials(client_id, client_secret, key_pix, priv_token)
        pay = Juno(objeto)
        qr = await pay.create_payment(value=value, user_id=m.from_user.id)

    elif select_pay == 'asaas':
        pay = Asaas(
            cur.execute(
                'SELECT client_secret FROM tokens WHERE type_token=?',
                [select_pay],
            ).fetchone()[0]
        )
        customer_id = cur.execute(
            'SELECT customer_id FROM users WHERE id=?', [m.from_user.id]
        ).fetchone()[0]

        if not customer_id:
            customer_id = await pay.add_to_client(
                full_name, cpf, m.from_user.id
            )

        await pay.create_cob(
            customer_id,
            value,
            desc='recursos/servições digitais ',
            user_id=m.from_user.id,
        )
        qr = await pay.get_QRcode()

    elif select_pay == "open pix":
        appID = cur.execute("SELECT client_secret FROM tokens WHERE type_token=?", [select_pay]).fetchone()[0]
        pay = OpenPix(appID)
        qr = await pay.create_cob(value * 100, user_id=m.from_user.id)
    else:
        return
    


    qr_code = qrcode.make(qr)
    user_id = m.from_user.id
    qr_code_path = f"qrcode/{user_id}_qrcode.png"
    qr_code.save(qr_code_path)


    base = (
        "<b>✅ Pagamento gerado:</b>\n\n"
        "<b>💰 Valor a ser pago: R$ {:.2f}</b>\n\n"
        "<b>⏱ Prazo de expiração: 30 Minutos</b>\n\n"
        "<b>💠 Pix Copia e Cola:</b>\n"
        "`{}`\n\n"
        "<b>💡 Dica: Clique no código acima para copiá-lo.</b>\n\n"
        "<b>⚠️ ATENÇÃO:</b>\n"
        "<i>Após o pagamento aguarde até o prazo de expiração para que o seu saldo seja creditado automaticamente.</i>"
    ).format(float(value), qr)

    
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='⌛️ Aguardando Pagamento', callback_data='confirm_payment'
                )
            ]
        ]
    )


    qr_message = await c.send_photo(
        chat_id=m.chat.id,
        photo=qr_code_path,
    )

   
    send = await mm.reply_text(
        text=base,
        reply_markup=kb
    )

 
    mention = create_mention(m.from_user, with_id=False)

    
    asyncio.create_task(verify_pay(
        objeto=pay,
        c=c,
        m=m,
        send=send,
        value=value,
        qr_message=qr_message,
        mention=mention,
        user_id=m.from_user.id
    ))
