import asyncio
import random
from .start import start  

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
)

from config import PRIVADO
from database import cur, save
from utils import (
    create_mention,
    get_info_wallet,
    get_pricefull,
    insert_buy_sold_full,
    insert_sold_balance,
    lock_user_buy_full,
    msg_buy_off_user,
    msg_buy_user,
    msg_buy_user_full,
    msg_group_adm_full,
)

from ..admins.panel_items.select_gate import GATES

gates = GATES

gates_is_on = lambda: True if (len(gates) >= 1) else False

SELLERS, TESTED = 0, 0


async def chking(card):
    global gates
    name_chk, _ = cur.execute(
        'SELECT gate_chk, gate_exchange FROM bot_config'
    ).fetchone()
    return await gates[name_chk](card)


def rate_ccs():
    global SELLERS, TESTED
    rate = (SELLERS / TESTED) * 100
    return rate
    
    
 # Pesquisa de CCs via inline.
@Client.on_inline_query(filters.regex(r"^fulld_(?P<type>\w+) (?P<value>.+)"))
async def fulld_(c: Client, m: InlineQuery):
    """
    Pesquisa uma CC via inline por tipo e retorna os resultados via inline.

    O parâmetro `type` será o tipo de valor para pesquisar, ex.:
        bin (Por bin), bank (Por banco), vendor (Por bandeira), etc.
    O parâmetro `value` será o valor para pesquisa, ex.:
        550209 (Bin), Nubank (Banco), Mastercard (Bandeira), etc.
    """

    typ = m.matches[0]["type"]
    qry = m.matches[0]["value"]

    # Não aceitar outros valores para prevenir SQL Injection.
    if typ not in ("bin", "banco", "bandeira", "paises"):
        return

    if typ != "bin":
        qry = f"%{qry}%"

    if typ == "banco":
        typ2 = "bank"
    elif typ == "bandeira":
        typ2 = "vendor"
    elif typ == "paises":
        typ2 = "country"
    else:
        typ2 = typ

    rt = cur.execute(
        f"SELECT number, month, year, {typ2}, level FROM cards_full WHERE {typ2} LIKE ? AND pending = 0 ORDER BY RANDOM() LIMIT 50",
        [qry.upper()],
    ).fetchall()

    results = []

    wallet_info = get_info_wallet(m.from_user.id)

    for number, month, year, value, level in rt:

        price = await get_pricefull("full", level)

        base = f"""Cartão: {number[0:6]}**********
Validade: {month}/{year}
Cvv: ***"""

        base_ml = f"""<b>Cartão:</b> <i>{number[0:6]}**********</i>
<b>Validade:</b> <i>{month}/{year}</i>
<b>Cvv:</b> <i>***</i>

<b>Valor:</b> <i>R$ {price}</i>"""

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="✅ Comprar",
                        callback_data=f"cc_fulld bin '{number[0:6]}' {month}|{year}",
                    )
                ]
            ]
        )

        results.append(
            InlineQueryResultArticle(
                title=f"{typ} {value} - R$ {price}",
                description=base,
                input_message_content=InputTextMessageContent(
                    base_ml + "\n\n" + wallet_info
                ),
                reply_markup=kb,
            )
        )

    await m.answer(results, cache_time=5, is_personal=True)
    
    
@Client.on_callback_query(
    filters.regex(
        r"^cc_fulld (?P<type>[a-z]+) '(?P<level_cc>.+)' ?(?P<other_params>.+)?"
    )
)
@lock_user_buy_full
async def buy_final_full(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    balance: int = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]  # fmt: skip

    type_cc = m.matches[0]["type"]
    level_cc = m.matches[0]["level_cc"]

    price = await get_pricefull(type_cc, level_cc)

    if balance < price:
        return await m.answer(
            "Você não possui saldo para realizar esta compra. Por favor, adicione saldo no menu principal.",
            show_alert=True,
        )

    search_for = "level" if type_cc == "full" else "bin"

    ccs_list = cur.execute(
        f"SELECT number, month, year, cvv, level, added_date, vendor, bank, country, cpf, name FROM cards_full WHERE {search_for} = ? AND pending = ? ORDER BY RANDOM() LIMIT 20",
        [level_cc, False],
    ).fetchall()

    if not ccs_list:
        return await m.answer("Não há CCs disponíveis deste nível.")

    if gates_is_on:
        live = 0
        await m.edit_message_text(
            "<b>🔄 Por favor aguarde , estou realizando a sua compra!</b>"
        )
        for tp in ccs_list:
            (
                number,
                month,
                year,
                cvv,
                level,
                added_date,
                vendor,
                bank,
                country,
                cpf,
                name,
            ) = tp

            card = "|".join([number, month, year, cvv])
            is_pending = cur.execute(
                "SELECT pending FROM cards_full WHERE number = ?", [tp[0]]
            ).fetchone()
            # Se retornar None, a cc já foi vendida ou marcada die.
            # Se is_pending[0] for True, ela está sendo verificada por outro processo.
            if not is_pending or is_pending[0]:
                continue
            cur.execute("UPDATE cards_full SET pending = 1 WHERE number = ?", [tp[0]])
            live_or_die = await chking(card)
            live_or_die[1]
            T = 5
            await asyncio.sleep(T)

            list_dados = tp + (user_id, type_cc, True)

            if live_or_die[0]:  # caso venha cc live
                diamonds = (price / 100) * 8
                new_balance = round(balance - price, 2)

                cur.execute(
                    "UPDATE users SET balance = round(balance - ?, 2), balance_diamonds = round(balance_diamonds + ?, 2) WHERE id = ?",
                    [price, diamonds, user_id],
                )
                dados = (name, cpf) if cpf != None else None
                base = await msg_buy_user_full(
                    user_id,
                    card,
                    vendor,
                    country,
                    bank,
                    level_cc,
                    price,
                    diamonds,
                    dados,
                )

                cur.execute(
                    "DELETE FROM cards_full WHERE number = ?",
                    [tp[0]],
                )

                insert_buy_sold_full(list_dados)
                insert_sold_balance(price, user_id, "cards_full")

                kb = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="Não passou? Peça reembolso",
                                callback_data=f"reembolsofull {number} {price}",
                            ),
                        ],
                    ]
                )

                await m.edit_message_text(base, reply_markup=kb)

                mention = create_mention(m.from_user)

                adm_msg = msg_group_adm_full(
                    mention,
                    card,
                    level_cc,
                    type_cc,
                    price,
                    live_or_die[1],
                    new_balance,
                    vendor,
                )
                await c.send_message(PRIVADO, adm_msg)
                
                kb = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="Compre as melhores ccs",
                            ),
                        ],
                    ]
                )
                mention = m.from_user.first_name
                
                adm_msg = msg_group_adm_full(
                    mention,
                    card,
                    level_cc,
                    type_cc,
                    price,
                    live_or_die[1],
                    new_balance,
                    vendor,
                )
                await c.send_message(PRIVADO, adm_msg, reply_markup=kb)
                
                

                kb = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text=" ❮❮ ", callback_data="comprar_cc"
                            ),
                        ],
                    ]
                )
                try:
                    await m.message.reply_text(
                        "✅ Compra realizada com sucesso. Clique no botão abaixo para voltar para o menu principal.",
                        reply_markup=kb,
                    )
                except:
                    ...
                save()
                return

            elif live_or_die[0] is None:  # ccs type return None
                cur.execute(
                    "UPDATE cards_full SET pending = False WHERE number = ?", [tp[0]]
                )

            else:  # para ccs_die
                cur.execute(
                    "DELETE FROM cards_full WHERE number = ?",
                    [tp[0]],
                )
                values = "number, month, year, cvv, level, added_date, vendor, bank, country, cpf, name, plan"
                list_dies = tp + (type_cc,)
                cur.execute(
                    f"INSERT INTO cards_dies_full({values}) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    list_dies,
                )

        if (live == 0) and gates_is_on:
            txt = "❗️ Não consegui achar CCs lives deste nível na minha database. Tente novamente com outro nível ou bin."
            kb = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text=" ❮❮ ", callback_data="comprar_full"
                        ),
                    ],
                ]
            )
        else:
            txt = (
                "⚠️ Parece que todas as gates do bot esão offline, você deseja continuar ou tentar novamente?\n"
                "Ao continuar, sua compra será efetuada <b>sem verificar</b>, ou seja, ela <b>não possuirá troca</b>."
            )
            kb = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🔁 Tentar novamente",
                            callback_data=m.data,
                        ),
                        InlineKeyboardButton(
                            text="✅ Continuar",
                            callback_data=f"buy_off {type_cc} '{level_cc}'",
                        ),
                    ],
                    [
                        InlineKeyboardButton(text="« Cancelar", callback_data="start"),
                    ],
                ]
            )
        await m.edit_message_text(txt, reply_markup=kb)

    # operação de venda caso as gates estejam off
    else:
        txt = (
            "⚠️ Parece que todas as gates do bot esão offline, você deseja continuar?\n"
            "Ao continuar, sua compra será efetuada <b>sem verificar</b>, ou seja, ela <b>não possuirá troca</b>."
        )
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="✅ Continuar",
                        callback_data=f"buy_off {type_cc} '{level_cc}'",
                    ),
                    InlineKeyboardButton(text="« Cancelar", callback_data="start"),
                ],
            ]
        )
        await m.edit_message_text(txt, reply_markup=kb)

    save()