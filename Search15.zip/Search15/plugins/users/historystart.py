import io
import os
from typing import Union

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

import sqlite3

db = sqlite3.connect("main.db")
cur = db.cursor()

@Client.on_message(filters.command(["historystart"]))
@Client.on_callback_query(filters.regex("^historystart$"))
async def history_menu(c: Client, m: Union[Message, CallbackQuery]):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬇️ Baixar histórico", callback_data="download_info"),
            ],
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="user_info"),
            ],
        ]
    )

    user_id = m.from_user.id

    # Calcula o total de cartões vendidos para o usuário
    total_aux = cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", [user_id]).fetchone()[0]
    
    total_full = cur.execute("SELECT COUNT(*) FROM cards_sold_full WHERE owner = ?", [user_id]).fetchone()[0]

    # Obtém o saldo do usuário
    total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

    # Calcula o total de recargas feitas pelo usuário
    total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text

    await send(
        f"""<b>📃 Histórico de Cartões.</b>\n<b>

<b>💳 Cartões:</b> <code>{total_full}</code>

<b>💰 Saldo:</b> <code>{total_balance}</code>

<b>💠 Recargas:</b> <code>{total_recargas}</code>

<b>Atenção</b>:  <i>Os valores presentes nesta sessão, é o total comprado, adicionado, respectivamente.
Baixe seu histórico para obter a lista de todos os cartões adquiridos.</i>
""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r'^download_info$'))
async def download_info(c: Client, m: CallbackQuery):
    user_id = m.from_user.id

    # Calcula o total de cartões vendidos para o usuário
    total_aux = cur.execute(
        'SELECT number, month, year, cvv FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50',
        [m.from_user.id],
    ).fetchall()

    total_full = cur.execute(
        "SELECT number, month, year, cvv, cpf, name bought_date FROM cards_sold_full WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    # Obtém o saldo do usuário
    total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

    # Calcula o total de recargas feitas pelo usuário
    total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

    info_text = f"Total de cc aux: {total_aux}\n\\n\nTotal de cc full: {total_full}\n\\n\nSaldo: {total_balance}\n\nTotal de Recargas: {total_recargas}"

    # Escreve as informações em um arquivo temporário
    with io.open(f'historico_{user_id}.txt', 'w', encoding='utf-8') as f:
        f.write(info_text)

    # Envia o arquivo ao usuário
    await m.message.reply_document(
        document=f'historico_{user_id}.txt',
        caption="Aqui estão suas informações de conta.",
    )

    # Remova o arquivo temporário após o envio
    os.remove(f'historico_{user_id}.txt')
