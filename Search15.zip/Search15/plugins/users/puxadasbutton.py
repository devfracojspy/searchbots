from pyrogram import Client, filters
from pyrogram.handlers import MessageHandler
from pyrogram.types import Message
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save, db
from utils import get_info_wallet

import datetime
from typing import Union
import asyncio
import io
import sqlite3  # Certifique-se de que você importou a biblioteca apropriada.

@Client.on_callback_query(filters.regex(r"^buttoncpf1$"))
async def buttoncpf1(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
               InlineKeyboardButton("❮❮", callback_data="botaocpf")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙 - 𝗧𝗜𝗣𝗢 </b>

━━━━━━━━━━━━━━━━━━
Status: ✅ Online
━━━━━━━━━━━━━━━━━━

<b>/cpf 00000000000</b>
<b>/cpf2 00000000000</b>
<b>/cpf3 00000000000</b>
<b>/cpf4 00000000000</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buttonnome1$"))
async def buttonnome1(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
               InlineKeyboardButton("❮❮", callback_data="botaonome")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗡𝗢𝗠𝗘 - 𝗧𝗜𝗣𝗢 </b>
		
━━━━━━━━━━━━━━━━━━
Status: ✅ Online
━━━━━━━━━━━━━━━━━━

<b>/nome JOSÉ EXEMPLO DO SANTOS</b>
<b>/nome2 JOSÉ EXEMPLO DO SANTOS</b>
<b>/nome3 JOSÉ EXEMPLO DO SANTOS</b>
""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buttonplaca1$"))
async def buttonplaca1(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
               InlineKeyboardButton("❮❮", callback_data="botaoplaca")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗣𝗟𝗔𝗖𝗔 - 𝗧𝗜𝗣𝗢 1</b>
		
━━━━━━━━━━━━━━━━━━
Status: ✅ Online
━━━━━━━━━━━━━━━━━━

<b>/placa ABC0000</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buttontel1$"))
async def buttontel1(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
               InlineKeyboardButton("❮❮", callback_data="botaotel")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 - 𝗧𝗜𝗣𝗢 </b>
		
━━━━━━━━━━━━━━━━━━
Status: ✅ Online
━━━━━━━━━━━━━━━━━━

<b>/tel 51955555555</b>
<b>/tel2 51955555555</b>
<b>/tel3 51955555555</b>
<b>/tel4 51955555555</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^botaocpf$"))
async def botaocpf(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
			   InlineKeyboardButton("CPF", callback_data="buttoncpf1"),
			],
		    [
               InlineKeyboardButton("❮❮", callback_data="puxadas")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔𝗦 𝗗𝗘 𝗖𝗣𝗙</b>

<b>🔘 CPF 1: Consulta simples de CPF, retorna os dados do portador.</b>

<b>🔘 CPF 2: Consulta completa de CPF, retorna os dados do portador. Incluindo dados Tipo 1 + número de RG, nome do pai e local de nascimento.</b>

<b>🔘 CPF 3: Consulta completa de CPF, retorna todos os dados do portador. Incluindo dados Tipo 2 + possíveis parentes, possíveis vizinhos, participação societária e vínculos empregatícios.</b>

<b>🔘 CPF 4: Consulta completa de CPF, retorna todos os dados do portador. Incluindo dados Tipo 2 + possíveis parentes, possíveis vizinhos, participação societária e vínculos empregatícios.</b>""",
        reply_markup=kb,
    )


@Client.on_callback_query(filters.regex(r"^botaonome$"))
async def botaonome(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
			   InlineKeyboardButton("NOME", callback_data="buttonnome1"),
			],
		    [
               InlineKeyboardButton("❮❮", callback_data="puxadas")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔𝗦 𝗗𝗘 𝗡𝗢𝗠𝗘</b>

<b>🔍 MENU | BASE NOME</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^botaotel$"))
async def botaotel(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
			   InlineKeyboardButton("TELEFONE", callback_data="buttontel1"),
			],
		    [
               InlineKeyboardButton("❮❮", callback_data="puxadas")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔𝗦 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘</b>

<b>🔍 MENU | BASE TELEFONE</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^botaoplaca$"))
async def botaoplaca(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
			[
			   InlineKeyboardButton("PLACA 1", callback_data="buttonplaca1"),
			],
		    [
               InlineKeyboardButton("❮❮", callback_data="puxadas")
		   ],
        ]
	)

    await m.edit_message_text(
        f"""<b>☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔𝗦 𝗗𝗘 𝗣𝗟𝗔𝗖𝗔</b>

<b>🔍 MENU | BASE PLACA</b>""",
        reply_markup=kb,
    )