import httpx
import time
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

from utils import insert_sold_balance
from database import cur, save

price = 1  # Price deve ser um número, não uma string

# URL da API de consulta de CPF
api_url = "https://nt-api.store/api/placapossuidor?apikey=&placa="

# Chat ID específico onde o comando /cpf será gratuito
free_chat_id = -1001741036602  # Substitua pelo chat_id correto

# Dicionário para rastrear o último uso do comando por usuário
last_command_usage = {}

GROUP_ID = -1001405866055

async def check_user_in_group(client, user_id: int):
    try:
        await client.get_chat_member(GROUP_ID, user_id)
        return True, None  
    except Exception as e:
        if "USER_NOT_PARTICIPANT" in str(e):
            message = "Para acessar esta puxada você deve se inscrever no botão abaixo:\n\n" \
                      "🔗 Se Inscrever"
            return False, message
        else:
            print("Error checking user in group: ", e)
            return False, 'Ocorreu um erro ao verificar sua inscrição. Tente novamente mais tarde.'

@Client.on_message(filters.command(['placa']))
async def placa_command(client, message: Message):
    if message is None:
        return

    # Verificar o saldo do usuário
    user_id = message.from_user.id  # Obtém o ID do usuário

    is_in_group, group_message = await check_user_in_group(client, user_id)
    if not is_in_group:
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton("🔗 Se Inscrever", url="https://t.me/netcomreferencias")]]
        )
        await message.reply_text(group_message, reply_markup=keyboard)
        return

    balance: int = cur.execute(
        "SELECT balance FROM users WHERE id = ?", [user_id]
    ).fetchone()[0]

    # Verificar se o comando está sendo usado no chat específico (gratuito)
    if message.chat.id != free_chat_id:
        if balance < price:
            await message.reply(
                "⚠️ Você não possui saldo. Por favor, faça uma Recarga."
            )
            return

    # Verificar o tempo desde o último uso do comando
    current_time = time.time()
    if user_id in last_command_usage:
        last_usage_time = last_command_usage[user_id]
        time_elapsed = current_time - last_usage_time
        if time_elapsed < 30:
            await message.reply(f"Você só pode usar o comando /placa novamente após {30 - int(time_elapsed)} segundos.")
            return

    # Obtém o CPF da mensagem do usuário
    try:
        placa = message.text.split(" ", 1)[1]
    except IndexError:
        await message.reply("Por favor, forneça um PLACA válido. Use /placa seguido do PLACA desejado.")
        return

    # Responda imediatamente para informar que a busca está em andamento
    msg = await message.reply("Aguarde enquanto a busca é feita...")

    # Monta a URL da API com o CPF fornecido
    full_api_url = api_url + placa

    # Faz uma solicitação para a API
    async with httpx.AsyncClient() as http:
        try:
            response = await http.get(full_api_url, timeout=30.0)
            response.raise_for_status()
            result = response.json()

            # Verificar se a resposta está vazia ou não contém os dados esperados
            if not result or "status" not in result:
                await msg.edit("API com problemas. Tente outra base.")
                return

            # Verificar se a resposta da API contém um status de erro
            if result["status"] == "error":
                await msg.edit("API retornou um erro. Tente novamente mais tarde.")
                return

            # Crie um texto formatado para a resposta da API, excluindo as partes indesejadas
            response_text = ""
            for key, value in result.items():
                if key not in ("status", "token"):
                    response_text += f"{key}: {value}\n"

            # Marque a pessoa que fez a pesquisa
            await msg.edit(f"Busca da PLACA {placa}:\n{response_text}")

            cur.execute(
                "UPDATE users SET balance = round(balance - ?, 2) WHERE id = ?",
                [price, user_id],
            )

        except httpx.ReadTimeout:
            await msg.edit("A solicitação atingiu o tempo limite. Tente novamente mais tarde.")
        except httpx.HTTPError as e:
            await msg.edit(f"A API FICOU OFF")
        except Exception as e:
            await msg.edit(f"Ocorreu um erro ao consultar a API")
