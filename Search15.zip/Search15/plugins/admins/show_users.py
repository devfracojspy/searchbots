from typing import Union
import io
import os

from pyrogram import Client, filters
from pyrogram.errors.exceptions.bad_request_400 import UserIsBlocked
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    InlineQueryResultArticle,
    InputTextMessageContent,
)

from config import DONO
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

@Client.on_callback_query(filters.regex("^add_users_from_txt$"))
async def add_users_from_txt_command(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    await c.send_message(
        m.message.chat.id,
        "Por favor, envie um arquivo .txt contendo as informações dos usuários no formato 'ID do Usuário | Username | Saldo' para adicionar ao banco de dados. "
        "Você pode cancelar esta operação a qualquer momento com /done."
    )

@Client.on_message(filters.document & filters.private)
async def process_txt_file(c: Client, m: Message):
    if m.caption and m.caption.lower() == "/done":
        await m.reply("Comando cancelado com sucesso.")
        return

    if not m.document.file_name.endswith(".txt"):
        await m.reply("Por favor, envie apenas arquivos .txt.")
        return

    # Baixe o arquivo .txt
    file = await m.download()
    try:
        with open(file, "r") as txt_file:
            lines = txt_file.readlines()

        # Processar linhas do arquivo .txt e adicionar ao banco de dados
        for line in lines:
            # Verificar se a linha começa com o cabeçalho e ignorá-la
            if line.strip().startswith("ID do Usuário | Username | Saldo"):
                continue
            
            user_id, username, balance = line.strip().split("|")
            user_id = int(user_id)  # Converter ID do Usuário para inteiro
            if username.lower().strip() == "none":
                username = None  # Configurar para NULL se o username for "None"
            balance = float(balance)  # Converter o saldo para float
            
            # Verificar se o ID ou o username já existem na tabela
            cur.execute("SELECT id, username FROM users WHERE id = ? OR username = ?", (user_id, username))
            existing_user = cur.fetchone()
            
            if existing_user:
                # Pular para a próxima linha se o ID ou o username já existirem na tabela
                continue
            
            cur.execute("INSERT INTO users (id, username, balance) VALUES (?, ?, ?)", (user_id, username, balance))

        conn.commit()
        await m.reply("Dados adicionados ao banco de dados com sucesso.")
    except Exception as e:
        await m.reply(f"Ocorreu um erro ao processar o arquivo: {str(e)}")
    finally:
        os.remove(file)

@Client.on_message(filters.command(["show_users", "users"]))
@Client.on_callback_query(filters.regex("^show_users$"))
async def total_banned_users(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    cur.execute("SELECT COUNT(*) FROM users")
    count_total = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM users WHERE is_blacklisted = 0 AND is_action_pending = 0")
    count_unblocked = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM users WHERE is_blacklisted = 1 AND is_action_pending = 0")
    count_blocked_bot = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM users WHERE is_blacklisted = 1 AND is_action_pending = 1")
    count_banned = cur.fetchone()[0]

    text = (
        f"<b>👤 - Usuários:<b>\n"
        f"<b>🌐 -Total de Usuários:</b> {count_total}\n"
        f"<b>❌ -Usuários Restringidos pelo bot:</b> {count_blocked_bot}\n"
    )

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⏬ Baixar usuários", callback_data="download_users_with_balance"),
                InlineKeyboardButton("⏫ Adicionar Usuários", callback_data="add_users_from_txt"),
            ],
            [
                InlineKeyboardButton(
                    "🔎 Buscar Usuários", switch_inline_query_current_chat="search_user "
                ),
                InlineKeyboardButton("🏆 Ranking", callback_data="ranking"),
            ],
            [
                InlineKeyboardButton("🚫 Usuários Restringidos", callback_data="banned_users"),
            ],
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="painel"),
            ],
        ]
    )

    # Check if m is an instance of CallbackQuery to determine how to update the message.
    if isinstance(m, CallbackQuery):
        message = m.message
    else:
        message = m

    await message.edit_text(
        text,
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex("^download_users_with_balance$"))
async def download_users_with_balance_callback(c: Client, m: CallbackQuery):
    cur.execute("SELECT id, username, COALESCE(balance, 0) FROM users")
    users_with_balance = cur.fetchall()

    if not users_with_balance:
        await m.answer("Não há usuários no bot.")
        return

    # Criar o conteúdo do arquivo TXT
    file_content = "ID do Usuário | Username | Saldo\n"
    for user_id, username, balance in users_with_balance:
        file_content += f"{user_id} | {username} | {balance}\n"

    # Criar o arquivo como um objeto de IO
    file_io = io.BytesIO(file_content.encode())

    # Enviar o arquivo como documento
    await c.send_document(
        m.from_user.id,
        file_io,
        caption="Aqui estão os usuários do bot.",
        file_name="usuarios.txt"  # Adicione o nome do arquivo diretamente aqui
    )

@Client.on_callback_query(filters.regex("^banned_users$"))
async def show_banned_users(c: Client, m: CallbackQuery):
    cur.execute("SELECT id, username FROM users WHERE is_blacklisted = 1 AND is_action_pending = 0")
    banned_users = cur.fetchall()

    if not banned_users:
        await m.answer("Não há usuários banidos.")
        return

    text = "<b>🚫 Usuários Banidos:<b>\n\n"

    for user_id, username in banned_users:
        mention = f"@{username}" if username else "Usuário não possui username"
        text += f"\n{mention} (ID: {user_id})"

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="show_users"),
            ],
        ]
    )

    # Send the message to the user
    await c.send_message(
        m.from_user.id,
        text,
        reply_markup=kb,
        disable_web_page_preview=True,
    )
