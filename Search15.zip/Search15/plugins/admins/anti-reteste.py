import re, httpx, asyncio, hashlib, os
import sqlite3
from config import DONO
from database import cur, save
from datetime import datetime
from typing import Union
from anti import TOKEN, USER_ID
from pyrogram import Client, filters
from pyrogram.types import Message, ForceReply, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardRemove

timeout = httpx.Timeout(20, pool=None)
hc = httpx.AsyncClient(http2=True, timeout=timeout)

def validate_credit_card(number):
    """
    Verifica se um número de cartão de crédito é válido, suportando todos os tipos de cartões existentes.
    Retorna True se o número for válido, caso contrário False.
    """
    # Remove espaço em branco e hifens
    number = number.replace(" ", "").replace("-", "")
    
    # Verifica se é um número válido
    if not number.isdigit():
        return False
    
    # Verifica se o número possui no mínimo 13 dígitos e no máximo 19 dígitos
    if not 13 <= len(number) <= 19:
        return False
    
    # Calcula a soma dos dígitos do número de cartão de crédito
    sum = 0
    even = len(number) % 2 == 0
    for i, digit in enumerate(number):
        digit = int(digit)
        if (even and i % 2 == 0) or (not even and i % 2 == 1):
            digit *= 2
            if digit > 9:
                digit -= 9
        sum += digit
    
    # Verifica se a soma é divisível por 10
    return sum % 10 == 0

def is_valid(now: datetime, month: Union[str, int], year: Union[str, int]) -> bool:
    """Verifica se a CC está dentro da data de validade."""

    now_month = now.month
    now_year = now.year

    # Verifica se o ano for menor que o ano atual.
    if int(year) < now_year:
        return False

    # Se o ano for o mesmo que o atual, verifica se o mês é menor que o atual.
    if int(month) < now_month and now_year == int(year):
        return False

    return True

async def retest_verify(card):
    card_hash = hashlib.sha256(card.encode()).hexdigest()
    link = f"http://185.211.4.75:3000/insert?token={TOKEN}&hash={card_hash}"
    try:
        rt = await hc.get(f"{link}")
        rj = rt.json()
        if rj.get("error") == True:
            return None, None, None, None
        else:
            already_exists = rj.get("already_exists")
            id_user = rj.get("added_by")
            added_date = rj.get("addition_date")
            try:
                users_attempts = rj.get("users_attempts")
            except:
                users_attempts = None
            if str(id_user) == str(USER_ID):
                return None, None, None, None
            else:
                return already_exists, id_user, added_date, users_attempts
    except Exception as err:
        print(err)
        return None, None, None

async def iter_add_cards(cards, c: Client, m: Message):
    err = []
    inv = []
    venc = []
    ret = []
    ccs = []

    total_lines = len(cards.split('\n'))
    progress_message = await m.reply_text("🚀 Iniciando o processo de verificação...")

    for index, line in enumerate(cards.split('\n')):
        if not line.strip():
            continue
        row = re.match(
            r".*?(?P<number>\d{15,16})\W+(?P<month>\d{1,2})\W+(?P<year>\d{2,4})\W+(?P<cvv>\d{3,4})\W*(?P<cpf>\d{3}.?\d{3}.?\d{3}.?\d{2})?\W*(?P<name>.+)?",
            line.strip()
        )
        if row is None:
            if line.strip():
                err.append(f"{line} --- Formatação inválida")
                continue
            else:
                continue
        else:
            year = "20" + row["year"] if len(row["year"]) == 2 else row["year"]
            month = "0" + row["month"] if len(row["month"]) == 1 else row["month"]
            card = f'{row["number"]}|{month}|{year}|{row["cvv"].zfill(3)}'

            if not is_valid(datetime.now(), month, year):
                venc.append(f"{line} --- Cartão vencido")
                continue
            if not validate_credit_card(row["number"]):
                inv.append(f"{line} --- Número do Cartão é Inválido")
                continue
            retest, id_user, added_data, users_attempts = await retest_verify(card)
            if retest:
                if len(users_attempts) > 0:
                    users_attempts_list = []
                    for user in users_attempts:
                        id = user["id"]
                        attempt_date = user["attempt_date"]
                        users_attempts_list.append(f"User: {id} - Data: {attempt_date}")
                    users_attempts_str = ",".join(users_attempts_list)
                    users_attempts_str = f" Outras tentativas: ({users_attempts_str})"
                else:
                    users_attempts_str = ""

                ret.append(f"{line} --- Reteste (adicionado em {added_data} por {id_user}){users_attempts_str}")
                continue
            ccs.append(line)

        # Atualiza a mensagem de progresso
        progress = (index + 1) / total_lines * 100
        await progress_message.edit_text(f"🚀 Progresso: {progress:.2f}% ({index + 1}/{total_lines})")

    os.makedirs("result", exist_ok=True)

    # Salva os resultados em arquivos
    with open("result/erros.txt", "w") as f:
        f.write("\n".join(err))

    with open("result/reteste.txt", "w") as r:
        r.write("\n".join(ret))

    with open("result/invalidas.txt", "w") as i:
        i.write("\n".join(inv))

    with open("result/vencidas.txt", "w") as v:
        v.write("\n".join(venc))

    with open("cards.txt", "w") as f:
        f.write("\n".join(ccs))

    total = len(ccs) + len(err) + len(inv) + len(venc) + len(ret)
    await progress_message.edit_text("✔️ Processo de verificação concluído!")
    return total, len(ret), len(inv), len(venc), len(err)

@Client.on_message(filters.regex(r'/anti( (?P<cards>.+))?', re.S) & filters.user(DONO))
async def on_add_m(c: Client, m: Message):

    cards = m.matches[0]['cards']

    if cards:
        with open("cards.txt", "a") as f:
            f.write(cards + "\n")
        await m.reply_text('💳 CCs adicionadas ao arquivo.', quote=True)
        return

    await m.reply_text(
        '💳 Modo de adição ativo. Envie as CCs como texto ou arquivo e elas serão adicionadas e verificadas no anti-reteste.',
        reply_markup=ForceReply(),
    )

    first = True
    while True:
        if not first:
            await m.reply_text(
                '✔️ Envie mais CCs ou digite /done para sair do modo de adição e Verificar no Anti-Reteste.',
                reply_markup=ForceReply(),
            )

        try:
            msg = await c.wait_for_message(m.chat.id, timeout=300)
        except TimeoutError:
            await m.reply_text(
                '❕ O comando anterior foi cancelado automaticamente por inatividade.',
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[[InlineKeyboardButton(' ❮❮ ', callback_data='start')]]
                ),
            )
            return

        first = False

        if msg.text and msg.text.startswith('/done'):
            break

        if msg.document:
            cache = await msg.download()
            with open(cache) as f:
                msg.text = f.read()
            os.remove(cache)

        with open("cards.txt", "a") as f:
            f.write(msg.text + "\n")

        await msg.reply_text('💳 CCs adicionadas ao arquivo.', quote=True)

    await m.reply_text('✔ Saiu do modo de adição de CCs. Iniciando o Anti-Reteste Aguarde...', reply_markup=ReplyKeyboardRemove())
    await checker(c, m)

async def checker(c: Client, m: Message):
    if os.path.exists("cards.txt") and os.stat("cards.txt").st_size > 0:
        print("🔍 Iniciando a verificação...")

        total, total_reteste, total_invalidas, total_vencidas, total_erros = await iter_add_cards(open("cards.txt").read(), c, m)
        if not total:
            await m.reply_text("❌ Não encontrei CCs para verificar.")
        else:
            await m.reply_text(
                f"✅ Verificação concluída. \nTotal de {total} CCs processadas\n"
                f"Reteste: {total_reteste}\n"
                f"Invalidas: {total_invalidas}\n"
                f"Vencidas: {total_vencidas}\n"
                f"Erros: {total_erros}."
            )

            for filename, caption in [("reteste.txt", "Reteste"), ("invalidas.txt", "Cartões Inválidos"), ("vencidas.txt", "Cartões Vencidos"), ("erros.txt", "Erros de Formatação")]:
                filepath = os.path.join("result", filename)
                if os.path.exists(filepath) and os.stat(filepath).st_size > 0:
                    await c.send_document(chat_id=m.chat.id, document=filepath, caption=caption)

            for filename in ["reteste.txt", "invalidas.txt", "vencidas.txt", "erros.txt"]:
                open(os.path.join("result", filename), "w").close()
            open("cards.txt", "w").close()

    else:
        await m.reply_text("❌ Não encontrei CCs no arquivo cards.txt para verificar.")
