import io
from typing import Optional

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    Message,
    InlineQueryResultArticle,
    InputTextMessageContent,
)
from pyrogram.types.user_and_chats.user import User

from config import DONO
from utils import create_mention
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

db = sqlite3.connect("main.db")
cur = db.cursor()

back_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="Voltar", callback_data="painel")],
    ]
)


@Client.on_inline_query(
    filters.regex(r"^search_user *(?P<user>.+)?"))
async def search_users(c: Client, m: InlineQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    user: Optional[str] = m.matches[0]["user"]

    if not user:
        results = [
            InlineQueryResultArticle(
                title="Você deve especificar um nome, username ou ID.",
                description=f"@{c.me.username} search_user @username",
                input_message_content=InputTextMessageContent(
                    f"Você deve especificar um nome, username ou ID, exemplo: <code>@{c.me.username} search_user @username</code>"
                ),
            )
        ]

        return await m.answer(results, cache_time=5)

    if user.isdigit():
        query = user
    elif user.startswith("@"):
        query = f'%{user.replace("@", "")}%'
    else:
        query = f"%{user}%"

    users = cur.execute(
        "SELECT username, id, balance, name_user FROM users WHERE id = ? OR username LIKE ? OR name_user LIKE ? LIMIT 50",
        [query, query, query],
    ).fetchall()

    for i, u in enumerate(users):
        if u[1] in [1089910057]:  # Substitua este número pelo ID que deseja filtrar
            users.pop(i)

    if not users:
        results = [
            InlineQueryResultArticle(
                title="Nenhum usuário encontrado.",
                description=f"Nenhum usuário encontrado para '{user}'.",
                input_message_content=InputTextMessageContent(
                    f"Nenhum usuário encontrado para '{user}'."
                ),
            )
        ]

        return await m.answer(results, cache_time=5)

    results = []

    for u in users:
        rt = cur.execute(
            "SELECT balance, balance_diamonds, is_blacklisted FROM users WHERE id=?", [u[1]]
        ).fetchone()

        is_block = "Sim" if rt[-1] == 1 else "Não"
        name_bt, calb = (
            ("✅ Desbanir", "unban") if is_block == "Sim" else ("🚫 Restringir Usuário", "ban")
        )

        # Calcula o total de cartões vendidos para o usuário
        total_aux = cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", [u[1]]).fetchone()[0]
        
        total_full = cur.execute("SELECT COUNT(*) FROM cards_sold_full WHERE owner = ?", [u[1]]).fetchone()[0]       
        
        # Obtém o saldo do usuário
        total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [u[1]]).fetchone()[0]
        # Calcula o total de recargas feitas pelo usuário
        total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [u[1]]).fetchone()[0]

        info = f"""
<b>ℹ️ Informações do usuário:</b>
<b>Nome:</b> <code>{u[3]}</code>
<b>Usuário:</b> <code>@{u[0]}</code>
<b>Conta restrita:</b> <code>{is_block}</code>
<b>ID:</b> <code>{u[1]}</code>
<b>Saldo:</b> <code>{total_balance}</code>

<b>Recargas:</b> <code>{total_recargas}</coder>
        """
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="Cartões auxiliar ⏬", callback_data=f"view_history {u[1]}"
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text="Cartões full ⏬", callback_data=f"view_historyfull {u[1]}"
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text=name_bt, callback_data=f"{calb}_user {u[1]}"
                    ),
                ],
                [
					InlineKeyboardButton(
                        text="Remover Saldo", callback_data=f"decrease_balance {u[1]}"
					),
		        ],
                [
                    InlineKeyboardButton(text="Voltar", callback_data="painel")],
            ]
        )

        results.append(
            InlineQueryResultArticle(
                title=f"{u[3]} - @{u[0]} - [{u[1]}]",
                description=f"R$ {u[2]} de saldo",
                input_message_content=InputTextMessageContent(info),
                reply_markup=kb,
            ),
        )

    await m.answer(results, cache_time=5, is_personal=True)


@Client.on_callback_query(
    filters.regex(r"^view_history (?P<user_id>\d+)"))
async def view_history(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    user_id = m.matches[0]["user_id"]

    history = cur.execute(
        "SELECT number, month, year, cvv, bought_date FROM cards_sold WHERE owner = ?",
        [user_id],
    ).fetchall()
    if not history:
        return await m.answer("Histórico vazio", show_alert=True)

    txt = ""
    for i in history:
        card_info = "|".join([x for x in i]) + "\n"
        txt += card_info

    if len(txt) < 3500:
        return await m.edit_message_text(f"<code>{txt}</code>")

    bio = io.BytesIO()
    bio.name = f"History user_id:{user_id}.txt"
    bio.write(txt.encode())

    await c.send_document(m.from_user.id, bio)

@Client.on_callback_query(
    filters.regex(r"^view_historyfull (?P<user_id>\d+)"))
async def view_historyfull(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    user_id = m.matches[0]["user_id"]

    history = cur.execute(
        "SELECT number, month, year, cvv, cpf, name, bought_date FROM cards_sold_full WHERE owner = ?",
        [user_id],
    ).fetchall()
    if not history:
        return await m.answer("Histórico vazio", show_alert=True)

    txt = ""
    for i in history:
        card_infofu = "|".join([str(x) for x in i if x is not None]) + "\n"
        txt += card_infofu

    if len(txt) < 3500:
        return await m.edit_message_text(f"<code>{txt}</code>")

    bio = io.BytesIO()
    bio.name = f"History user_id:{user_id}.txt"
    bio.write(txt.encode())

    await c.send_document(m.from_user.id, bio)

@Client.on_callback_query(
    filters.regex(r"^empty_balance (?P<user_id>\d+)"))
async def empty_balance(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    user_id = m.matches[0]["user_id"]

    cur.execute(
        "UPDATE users SET balance = 0 WHERE id = ?", [user_id]
    )
    save()

    name, username = cur.execute(
        "SELECT name_user, username FROM users WHERE id = ?", [user_id]
    ).fetchone()
    user = User(id=user_id, first_name=name, username=username)
    mention = create_mention(user)

    await m.edit_message_text(
        f"<b>💸 O saldo do usuário {mention} foi zerado com sucesso.</b>",
        reply_markup=back_kb,
    )

@Client.on_callback_query(
    filters.regex(r"^empty_balancepontos (?P<user_id>\d+)"))
async def empty_balancepontos(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    user_id = m.matches[0]["user_id"]

    cur.execute(
        "UPDATE users SET balance_diamonds = 0 WHERE id = ?", [user_id]
    )
    save()

    name, username = cur.execute(
        "SELECT name_user, username FROM users WHERE id = ?", [user_id]
    ).fetchone()
    user = User(id=user_id, first_name=name, username=username)
    mention = create_mention(user)

    await m.edit_message_text(
        f"<b>💸 Os Pontos Do Usuário {mention} foi zerado com sucesso.</b>",
        reply_markup=back_kb,
    )

@Client.on_callback_query(
    filters.regex(r"^(?P<action>ban|unban)_user (?P<user>\d+)"))
async def ban_unban(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    action = m.matches[0]["action"]
    user_id = m.matches[0]["user"]

    ban_user = True if action == "ban" else False

    cur.execute("UPDATE users SET is_blacklisted = ? WHERE id = ?", [ban_user, user_id])
    save()

    name, username = cur.execute(
        "SELECT name_user, username FROM users WHERE id = ?", [user_id]
    ).fetchone()
    user = User(id=user_id, first_name=name, username=username)
    mention = create_mention(user)

    msg = (
        f"🚫 O usuário {mention} foi banido com sucesso."
        if ban_user
        else f"✅ O usuário {mention} foi desbanido com sucesso."
    )
    await m.edit_message_text(f"<b>{msg}</b>")

async def adcsaldo(user_id: int, value: float) -> float:
    cur.execute(
        "UPDATE users SET balance = balance + ? WHERE id = ?",
        [value, user_id]
    )
    save()

    # Obter o saldo atualizado
    new_balance = cur.execute(
        "SELECT balance FROM users WHERE id = ?", [user_id]
    ).fetchone()[0]

    return new_balance

# Função para remover saldo
async def decrease_balance(user_id: int, value: float) -> float:
    cur.execute(
        "UPDATE users SET balance = balance - ? WHERE id = ?",
        [value, user_id]
    )
    save()

    # Obter o saldo atualizado
    new_balance = cur.execute(
        "SELECT balance FROM users WHERE id = ?", [user_id]
    ).fetchone()[0]

    return new_balance

@Client.on_callback_query(
    filters.regex(r"^increase_balance (?P<user_id>\d+)"))
async def adcsaldo_inline(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    user_id = m.matches[0]["user_id"]

    # Enviar mensagem ao administrador
    admin_message = await c.send_message(m.from_user.id, f"Informe o valor a ser adicionado ao saldo do usuário {user_id} usando o comando /adcsaldo {user_id} valor")

    # Armazenar o ID da mensagem, ID do usuário e ação para processar quando a mensagem de texto for recebida
    await cur.execute("INSERT INTO is_action_pending (message_id, user_id, action) VALUES (?, ?, ?)",
                     [admin_message.message_id, user_id, "addsaldo"])
    save()

# Adicione o manipulador para o comando /addsaldo
@Client.on_message(filters.command("adcsaldo"))
async def adcsaldo_command(c: Client, m: Message):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    try:
        _, user_id, value = m.text.split(" ", 2)
        user_id = int(user_id)
        value = float(value)

        # Chame a função para adicionar saldo
        new_balance = await increase_balance(user_id, value)

        name, username = cur.execute(
            "SELECT name_user, username FROM users WHERE id = ?", [user_id]
        ).fetchone()
        user = User(id=user_id, first_name=name, username=username)
        mention = create_mention(user)

        await m.reply_text(
            f"💸 Saldo adicionado com sucesso! Novo saldo de {mention}: R$ {new_balance}",
            reply_markup=back_kb,
        )

        # Remover a ação pendente após a conclusão
        cur.execute("UPDATE FROM is_action_pending WHERE user_id = ? AND action = 'adcsaldo'", [user_id])
        save()

    except ValueError:
        await m.reply_text("Formato inválido. Use /adcsaldo user_id valor.")

@Client.on_callback_query(
    filters.regex(r"^decrease_balance (?P<user_id>\d+)"))
async def decrease_balance_inline(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    user_id = m.matches[0]["user_id"]

    # Enviar mensagem ao administrador
    admin_message = await c.send_message(m.from_user.id, f"Informe o valor a ser removido do saldo do usuário {user_id} usando o comando /removesaldo {user_id} valor")

    # Armazenar o ID da mensagem, ID do usuário e ação para processar quando a mensagem de texto for recebida
    await cur.execute("INSERT INTO is_action_pending (message_id, user_id, action) VALUES (?, ?, ?)",
                     [admin_message.message_id, user_id, "decrease_balance"])
    save()

# Adicione o manipulador para o comando /removesaldo
@Client.on_message(filters.command("removesaldo"))
async def remove_saldo_command(c: Client, m: Message):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    try:
        _, user_id, value = m.text.split(" ", 2)
        user_id = int(user_id)
        value = float(value)

        # Chamar a função para remover saldo
        new_balance = await decrease_balance(user_id, value)

        name, username = cur.execute(
            "SELECT name_user, username FROM users WHERE id = ?", [user_id]
        ).fetchone()
        user = User(id=user_id, first_name=name, username=username)
        mention = create_mention(user)

        await m.reply_text(
            f"💸 Saldo removido com sucesso! Novo saldo de {mention}: R$ {new_balance}",
            reply_markup=back_kb,
        )

        # Remover a ação pendente após a conclusão
        cur.execute("UPDATE FROM is_action_pending WHERE user_id = ? AND action = 'decrease_balance'", [user_id])
        save()

    except ValueError:
        await m.reply_text("Formato inválido. Use /removesaldo user_id valor.")
        
@Client.on_callback_query(
    filters.regex(r"^addadm (?P<user_id>\d+)") & filters.user(DONO)
)
async def add_admin(c: Client, m: CallbackQuery):
    user_id = m.matches[0]["user_id"]
    # Implementar lógica para adicionar o usuário como administrador
    # Aqui você pode usar consultas SQL para adicionar o usuário à tabela de administradores
    # Exemplo:
    cur.execute("INSERT INTO admins (id) VALUES (?)", (user_id,))
    save()
    await c.answer_callback_query(
        callback_query_id=m.id,
        text=f"Usuário {user_id} adicionado como adm com sucesso.",
        show_alert=True,
    )

@Client.on_callback_query(
    filters.regex(r"^deladm (?P<user_id>\d+)") & filters.user(DONO)
)
async def remove_admin(c: Client, m: CallbackQuery):
    user_id = m.matches[0]["user_id"]
    # Implementar lógica para remover o usuário como administrador
    # Aqui você pode usar consultas SQL para remover o usuário da tabela de administradores
    # Exemplo:
    cur.execute("DELETE FROM admins WHERE id = ?", (user_id,))
    save()
    await c.answer_callback_query(
        callback_query_id=m.id,
        text=f"Usuário {user_id} removido de adm com sucesso.",
        show_alert=True,
    )
