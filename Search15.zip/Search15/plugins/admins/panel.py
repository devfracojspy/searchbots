from typing import Union

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import DONO
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

@Client.on_message(filters.command("painel"))
@Client.on_callback_query(filters.regex("^painel$"))
async def panel(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🚦 Status do bot", callback_data="bot_status"),
                InlineKeyboardButton("💠 Pix", callback_data="auto_pay"),
            ],
            [
                InlineKeyboardButton("💵 Preços", callback_data="change_prices"),
                InlineKeyboardButton("🔃 Gates", callback_data="select_gate"),
            ],
            [
                InlineKeyboardButton('💳 Estoque', callback_data='estoques'),
                InlineKeyboardButton('🫂 Usuários', callback_data='show_users'),
            ],
            [
                InlineKeyboardButton("➕ Dobro saldo", callback_data="dobro"),
                InlineKeyboardButton("🔄 Config trocas", callback_data="settings")
            ],
            [
                InlineKeyboardButton("ℹ️ Outras configs", callback_data="bot_config"),    

            ],
            
        ]
    )

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text

    await send(
        """<b>👑 Painel administrativo da store!</b>
<code> - Versão: 1.0.0 (Search) (13/01/2025)</code>

<i>-Selecione abaixo o que você deseja visualizar ou modificar.</i>""",
        reply_markup=kb,
    )


@Client.on_message(
    filters.command(["settings", "set", "config", "setting"]))
@Client.on_callback_query(filters.regex("^settings"))
async def settings(c: Client, m: Union[CallbackQuery, Message]):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    m = m.reply_text if isinstance(m, Message) else m.message.edit_text
    exhance_is = cur.execute("SELECT exchange_is FROM bot_config").fetchone()[0]
    msg, calb = (
        ("🚫 Desabilitar", "exchange_0")
        if exhance_is == 1
        else ("✅ Habilitar", "exchange_1")
    )
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🕐 Tempo de troca", callback_data="set time")],
            [InlineKeyboardButton(text=msg, callback_data=f"set {calb}")],
            [InlineKeyboardButton(text="🔙 Voltar", callback_data="painel")],
        ]
    )
    await m("<b>🔃 Trocas!</b>", reply_markup=kb)


@Client.on_callback_query(filters.regex(r"^set (?P<action>\w+)"))
async def set_exchange(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    action = m.matches[0]["action"]

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Voltar", callback_data="painel")]
        ]
    )

    if action == "time":
        await m.message.delete()
        new_time = await m.message.ask(
            "Digite o tempo de troca",
            filters=filters.regex(r"^\d+"),
            reply_markup=ForceReply(),
        )
        cur.execute("UPDATE bot_config SET time_exchange=?", [int(new_time.text)])
        save()
        return await m.message.reply_text(
            f"Tempo de troca alterado com sucesso. Novo tempo {new_time.text}m",
            reply_markup=kb,
        )
    st = action.split("_")[1]
    is_exch = "habilitadas" if st == 1 else "Desabilitadas"
    cur.execute("UPDATE bot_config SET exchange_is=?", [int(st)])
    save()
    return await m.edit_message_text(
        f"<b>Trocas {is_exch} com sucesso.</b>", reply_markup=kb
    )

@Client.on_message(filters.command('estoques'))
@Client.on_callback_query(filters.regex('^estoques$'))
async def estoques(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton('💳 Estoque AUX', callback_data='stock cards'),
                InlineKeyboardButton('💳 Estoque Full', callback_data='stockfull cards_full'),
            ],
            [
                InlineKeyboardButton(
                    '🔙 Voltar', callback_data='painel'
                )
            ],
        ]
    )

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text

    await send(
        """<b>💳 Estoque!</b>
""",
        reply_markup=kb,
    )
