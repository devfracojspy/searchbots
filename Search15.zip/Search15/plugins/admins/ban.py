from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineQuery, InputTextMessageContent, InlineQueryResultArticle
from utils import is_user_banned
from config import DONO
from database import cur, save
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0
        
# Comando para banir usuários
@Client.on_message(filters.command("ban"))
async def ban_command(client, message: Message):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await message.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    try:
        # Obter o ID do usuário a ser banido
        user_id = int(message.command[1])

        # Banir o usuário
        cur.execute("UPDATE users SET is_blacklisted = 1 WHERE id = ?", [user_id])
        save()

        # Responder com uma mensagem de sucesso
        await message.reply_text(f"✅ Usuário {user_id} banido com sucesso!")
    except (IndexError, ValueError):
        # Lidar com erros se os argumentos não foram fornecidos corretamente
        await message.reply_text("❌ Por favor, forneça um ID de usuário válido. Exemplo: /ban 123456789")

# Comando para banir usuários via callback
@Client.on_callback_query(filters.regex(r"^(?P<action>ban)_user (?P<user>\d+)"))
async def ban_callback(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    action = m.matches[0]["action"]
    user_id = m.matches[0]["user"]

    # Banir o usuário
    cur.execute("UPDATE users SET is_blacklisted = 1 WHERE id = ?", [user_id])
    save()

    # Responder com uma mensagem de sucesso
    await m.edit_message_text(f"✅ Usuário {user_id} banido com sucesso!")

# Comando para desbanir usuários
@Client.on_message(filters.command("unban"))
async def unban_command(client, message: Message):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await message.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    try:
        # Obter o ID do usuário a ser banido
        user_id = int(message.command[1])

        # Banir o usuário
        cur.execute("UPDATE users SET is_blacklisted = 0 WHERE id = ?", [user_id])
        save()

        # Responder com uma mensagem de sucesso
        await message.reply_text(f"✅ Usuário {user_id} desbanido com sucesso!")
    except (IndexError, ValueError):
        # Lidar com erros se os argumentos não foram fornecidos corretamente
        await message.reply_text("❌ Por favor, forneça um ID de usuário válido. Exemplo: /unban 123456789")
        
@Client.on_callback_query(filters.regex(r"^(?P<action>unban)_user (?P<user>\d+)"))
async def unban_callback(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    action = m.matches[0]["action"]
    user_id = m.matches[0]["user"]

    # Banir o usuário
    cur.execute("UPDATE users SET is_blacklisted = 0 WHERE id = ?", [user_id])
    save()

    # Responder com uma mensagem de sucesso
    await m.edit_message_text(f"✅ Usuário {user_id} desbanido com sucesso!")