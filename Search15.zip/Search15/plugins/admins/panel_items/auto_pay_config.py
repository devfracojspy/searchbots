import asyncio
from typing import Union
import os
import shlex

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from config import DONO
from payments import AUTO_PAYMENTS
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0
    
response_queue = asyncio.Queue()

def if_exists():
    cur.executescript(
        """
    INSERT OR IGNORE INTO tokens(type_token) VALUES('mercado pago');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('gerencia net');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('pagbank');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('juno');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('asaas');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('open pix');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('easy');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('sampa');
    INSERT OR IGNORE INTO tokens(type_token) VALUES('ultra');
        """
    )
    save()


@Client.on_callback_query(filters.regex(r'^auto_pay$'))
async def pix_auto_config(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await message.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='♻ Tokens', callback_data='config charge_pix'
                ),
                InlineKeyboardButton(
                    text='✅ Selecionar Pix',
                    callback_data='config select_pix',
                )
            ],
            [
                InlineKeyboardButton("💰 valor Manual", callback_data="edit_add_value manual"),
                InlineKeyboardButton("💠 valor Auto", callback_data="edit_add_value auto")

            ],
            [InlineKeyboardButton(text='🔙 Voltar', callback_data='painel')],
        ]
    )

    await m.edit_message_text(
        '<b>Selecione uma opção para prosseguir</b>', reply_markup=kb
    )


@Client.on_callback_query(
    filters.regex(r'^config (?P<type>.+)'))
async def change_options(c: Client, m: CallbackQuery):
    user_id = m.from_user.id if isinstance(m, Message) else m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    type_config = m.matches[0]['type']
    opts = []
    for item in AUTO_PAYMENTS:
        opts.append(
            [
                InlineKeyboardButton(
                    text=f'∘ {item}', callback_data=f'{type_config} {item}'
                )
            ]
        )

    if type_config == 'select_pix':
        txt = '<b>Seleciona qual pix auto ira operar no bot</b>'
        opts.append(
            [
                InlineKeyboardButton(
                    text='Desativar Pix Auto', callback_data='select_pix off'
                )
            ]
        )
    else:
        txt = '<b>Em qual ira trocar os tokens.</b>'
    opts.append(
        [InlineKeyboardButton(text=' ❮❮ ', callback_data='painel')]
    )
    kb = InlineKeyboardMarkup(inline_keyboard=opts)

    await m.edit_message_text(text=txt, reply_markup=kb)


@Client.on_callback_query(
    filters.regex(r'^charge_pix (?P<name_pix>.+)'))
async def charge_token_pix(c: Client, m: CallbackQuery):
    user_id = m.from_user.id if isinstance(m, Message) else m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    await m.message.delete()
    if_exists()
    name_pix = m.matches[0]['name_pix']

    try:
        os.mkdir('payment_keys')
    except FileExistsError:
        pass

    if name_pix == 'gerencia net':
        client_id = await m.message.ask(
            '<i>Envie seu token</i> <b>CLIENT_ID</b>',
            reply_markup=ForceReply(),
        )
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>CLIENT_SECRET</b>',
            reply_markup=ForceReply(),
        )

        pix_key = await m.message.ask(
            '<b>💠 Sua chave pix</b>', reply_markup=ForceReply()
        )

        document = await m.message.ask(
            '<b>Envie seu arquivo .pem ou .p12</b>',
            filters=filters.document,
            reply_markup=ForceReply(),
        )

        out_file_name = os.path.join('payment_keys', 'gerencianet.pem')

        if document.document.file_name.lower().endswith('.pem'):
            await document.download(out_file_name)

        elif document.document.file_name.lower().endswith('.p12'):
            in_file_name = await document.download(
                os.path.join('payment_keys', 'gerencianet.p12')
            )

            proc = await asyncio.create_subprocess_shell(
                shlex.join(
                    [
                        "openssl",
                        "pkcs12",
                        "-in", in_file_name,
                        "-out", out_file_name,
                        "-nodes",
                        "-passin", "pass:",
                    ]  # fmt: skip
                )
            )

            await proc.communicate()

            os.remove(in_file_name)

            if proc.returncode != 0:
                return await m.message.reply_text(
                    'Ops, ocorreu um erro e o arquivo .p12 não pôde ser convertido para .pem.'
                )

        cur.execute(
            'UPDATE tokens SET client_id = ?, client_secret = ?, name_cert_pem = ?, key_pix = ? WHERE type_token = ?',
            [
                client_id.text,
                client_secret.text,
                out_file_name,
                name_pix,
                pix_key.text,
            ],
        )

    elif name_pix == 'mercado pago':
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>APP_USER</b>', reply_markup=ForceReply()
        )
        cur.execute(
            'UPDATE tokens SET client_secret = ? WHERE type_token = ?',
            [client_secret.text, name_pix],
        )
        save()
    
    elif name_pix == 'easy':
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>token</b>', reply_markup=ForceReply()
        )
        cur.execute(
            'UPDATE tokens SET client_secret = ? WHERE type_token = ?',
            [client_secret.text, name_pix],
        )
        save()

    elif name_pix == 'ultra':
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>token</b>', reply_markup=ForceReply()
        )

        client_id = await m.message.ask(
            '<i>Envie seu ID relativo ao token</i>', reply_markup=ForceReply()
        )

        cur.execute(
            'UPDATE tokens SET client_secret = ?, client_id = ? WHERE type_token = ?',
            [client_secret.text, int(client_id.text), name_pix],
        )
        save()
    
    elif name_pix == 'sampa':
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>token</b>', reply_markup=ForceReply()
        )
        cur.execute(
            'UPDATE tokens SET client_secret = ? WHERE type_token = ?',
            [client_secret.text, name_pix],
        )
        save()

    elif name_pix == 'juno':
        client_id = await m.message.ask(
            '<i>Envie seu token</i> <b>Clint_id</b>', reply_markup=ForceReply()
        )
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>Client_secret</b>',
            reply_markup=ForceReply(),
        )

        priv_token = await m.message.ask(
            '<i>Envie seu token</i> <b>Private token</b>',
            reply_markup=ForceReply(),
        )
        pix_key = await m.message.ask(
            '<b>💠 Sua chave pix</b>', reply_markup=ForceReply()
        )

        cur.execute(
            'UPDATE tokens SET client_id = ?, client_secret = ?, bearer_tk = ?, key_pix = ? WHERE type_token = ?',
            [
                client_id.text,
                client_secret.text,
                priv_token.text,
                pix_key.text,
                name_pix,
            ],
        )
        save()

    elif name_pix == 'pagbank':
        client_id = await m.message.ask(
            '<i>Envie seu token</i> <b>CLIENT_ID</b>',
            reply_markup=ForceReply(),
        )
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>CLIENT_SECRET</b>',
            reply_markup=ForceReply(),
        )

        pix_key = await m.message.ask(
            '<b>💠 Sua chave pix</b>', reply_markup=ForceReply()
        )

        pem_document = await m.message.ask(
            '<b>Envie seu arquivo .pem</b>',
            filters=filters.document,
            reply_markup=ForceReply(),
        )

        pem_file_name = os.path.join('payment_keys', 'pagbank.pem')
        await pem_document.download(pem_file_name)

        key_document = await m.message.ask(
            '<b>Envie seu arquivo .key</b>',
            filters=filters.document,
            reply_markup=ForceReply(),
        )

        key_file_name = os.path.join('payment_keys', 'pagbank.key')
        await key_document.download(key_file_name)

        cur.execute(
            'UPDATE tokens SET client_id = ?, client_secret = ?, name_cert_pem = ?, name_cert_key = ?, key_pix = ? WHERE type_token = ?',
            [
                client_id.text,
                client_secret.text,
                pem_file_name,
                key_file_name,
                pix_key.text,
                name_pix,
            ],
        )

        save()

    elif name_pix == 'asaas':
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>access_token</b>',
            reply_markup=ForceReply(),
        )
        old_token = cur.execute(
            'SELECT client_secret FROM tokens WHERE type_token=?', [name_pix]
        ).fetchone()[0]
        if old_token != client_secret.text:
            cur.execute('UPDATE users SET customer_id=null')

        cur.execute(
            'UPDATE tokens SET client_secret = ? WHERE type_token = ?',
            [client_secret.text, name_pix],
        )
        save()

    elif name_pix == 'open pix':
        client_secret = await m.message.ask(
            '<i>Envie seu token</i> <b>appID</b>', reply_markup=ForceReply()
        )
        cur.execute(
            'UPDATE tokens SET client_secret = ? WHERE type_token = ?',
            [client_secret.text, name_pix],
        )
        save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=' 🔙 ', callback_data='painel')]
        ]
    )

    await m.message.reply_text(
        '<b>Tokens atualizados com sucesso.</b>', reply_markup=kb
    )


@Client.on_callback_query(
    filters.regex(r'^select_pix (?P<pix_name>.+)'))
async def select_pix(c: Client, m: CallbackQuery):
    user_id = m.from_user.id if isinstance(m, Message) else m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    pix_name = m.matches[0]['pix_name']

    if pix_name == 'off':
        pix_name = None

    cur.execute('UPDATE bot_config SET pay_auto = ?', [pix_name])

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=' 🔙 ', callback_data='painel')],
        ]
    )

    await m.edit_message_text(
        f'Pix automático alterado com sucesso para {pix_name}.',
        reply_markup=kb,
    )
    save()

@Client.on_callback_query(filters.regex(r"^edit_add_value (?P<type>\w+)"))
async def edit_value_add_balance(c: Client, m: CallbackQuery):
    typ = m.matches[0]["type"]
    await m.message.delete()

    # Send a message to prompt user for input
    await c.send_message(
        chat_id=m.message.chat.id,
        text=f"Digite o novo valor para adição mínima do pix <b>{typ.upper()}</b>",
        reply_markup=ForceReply(),
    )

    # Wait for the user's response
    try:
        user_response = await asyncio.wait_for(response_queue.get(), timeout=60)
    except asyncio.TimeoutError:
        await c.send_message(
            chat_id=m.message.chat.id,
            text=f'❌ Tempo expirado. Por favor, tente novamente.',
        )
        return

    # Process the user's response
    if user_response.strip():
        cur.execute(f"UPDATE add_balance SET {typ}=?", [int(user_response)])
        save()
        await c.send_message(
            chat_id=m.message.chat.id,
            text=f'✅ valor "pix {typ.capitalize()}" alterado com sucesso.'
        )

@Client.on_message(filters.reply & filters.text)
async def handle_user_response(c: Client, m: Message):
    response_queue.put_nowait(m.text)
