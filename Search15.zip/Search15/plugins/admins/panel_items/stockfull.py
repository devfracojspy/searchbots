import io
from typing import Union

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import DONO
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

keys1 = {
    'cards_full': '💳 Disponíveis',
    'cards_sold_full': '💵 Vendidas',
    'cards_dies_full': '🗑 Trocas/Dies',
}

@Client.on_callback_query(
    filters.regex(r'^stockfull (?P<type_name>\w+)$'))
@Client.on_message(filters.command(['estoquefull', 'stockfull']))
async def ccs_stockfull(c: Client, m: Union[CallbackQuery, Message]):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    keys = keys1.copy()

    if isinstance(m, CallbackQuery):
        table_name = m.matches[0]['type_name']
        send = m.edit_message_text
    else:
        table_name = 'cards_full'
        send = m.reply_text

    # Altera o emoji da categoria ativa para ✅
    for key in keys:
        if key == table_name:
            keys[key] = '✅ ' + keys[key].split(maxsplit=1)[1]

    dies = cur.execute('SELECT count() from cards_dies_full').fetchone()[0]
    lives = cur.execute('SELECT count() from cards_sold_full').fetchone()[0]
    total = sum([dies, lives])
    msg = '⚠ Rate Full!'

    if total > 0:
        rate = round((lives / total * 100), 2)
        emoji = '📈' if rate > 50 else '📉'
        msg = f'{emoji} Rate {rate}%'

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(name, callback_data='stockfull ' + key)
                for key, name in keys.items()
            ],
            [
                InlineKeyboardButton(
                    text=f'⏬ Baixar {keys[table_name].split(maxsplit=1)[1].lower()}',
                    callback_data='downloadfull ' + table_name,
                ),
                InlineKeyboardButton(
                    text=f'⛔️ Apagar {keys[table_name].split(maxsplit=1)[1].lower()}',
                    callback_data='clearfull ' + table_name,
                ),
            ],
            [InlineKeyboardButton(text=msg, callback_data='rate')],
            [
                InlineKeyboardButton(' ❮❮ ', callback_data='estoques'),
            ],
        ]
    )

    full = cur.execute(
        f'SELECT level, count() FROM {table_name} GROUP BY level ORDER BY count() DESC'
    ).fetchall()

    stockfull = (
        '\n'.join([f'<b>{it[0]}</b>: {it[1]}' for it in full])
        or '<b>Nenhum item nesta categoria.</b>'
    )
    total = f'\n\n<b>Total</b>: {sum([int(x[1]) for x in full])}' if full else ''

    await send(
        f'<b>💳 Estoque - {keys[table_name].split(maxsplit=1)[1]}</b>\n\n{stockfull}{total}',
        reply_markup=kb if m.from_user.id in DONO else None,
    )


@Client.on_callback_query(
    filters.regex(r'^downloadfull (?P<table>\w+)'))
async def get_stockfull(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    table_name = m.matches[0]['table']

    # Tables para enviar por categorias
    if table_name == 'cards_full':
        tables = 'number, month, year, cvv, added_date, name, cpf'
    elif table_name == 'cards_sold_full':
        tables = 'number, month, year, cvv, added_date, bought_date, owner, name, cpf'
    elif table_name == 'cards_dies_full':
        tables = 'number, month, year, cvv, added_date, die_date, name, cpf'
    else:
        return

    full = cur.execute(f'SELECT {tables} FROM {table_name}').fetchall()

    txt = '\n'.join(['|'.join([str(d) for d in full]) for full in full])

    if len(txt) > 3500:
        bio = io.BytesIO()
        bio.name = table_name + '.txt'
        bio.write(txt.encode())
        return await m.message.reply_document(
            bio, caption=f'Ordem dos itens: {tables}', quote=True
        )

    return await m.message.reply_text(f'<code>{txt}</code>', quote=True)


@Client.on_callback_query(
    filters.regex(r'^clearfull (?P<table>\w+)'))
async def clear_table(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    table_name = m.matches[0]['table']

    table_str = keys1[table_name].split(maxsplit=1)[1].lower()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f'⛔️ Apagar {keys1[table_name].split(maxsplit=1)[1].lower()}',
                    callback_data='clear_confirmfull ' + table_name,
                ),
                InlineKeyboardButton(
                    text=' ❮❮ CANCELAR️',
                    callback_data='stockfull ' + table_name,
                ),
            ],
        ]
    )

    await m.edit_message_text(
        f'<b>⛔️ Apagar {table_str}</b>\n\n'
        f'Você tem certeza que deseja zerar o estoque de <b>{table_str}</b>?\n'
        'Note que <b>esta operação é irreversível</b> e um backup é recomendado.',
        reply_markup=kb,
    )


@Client.on_callback_query(
    filters.regex(r'^clear_confirmfull (?P<table>\w+)'))
async def clear_table_confirm(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    table_name = m.matches[0]['table']

    table_str = keys1[table_name].split(maxsplit=1)[1].lower()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=' ❮❮ ',
                    callback_data='stockfull ' + table_name,
                ),
            ],
        ]
    )

    cur.execute(f'DELETE FROM {table_name}')

    await m.edit_message_text(
        f'✅ Estoque de {table_str} apagado com sucesso.', reply_markup=kb
    )
    save()
