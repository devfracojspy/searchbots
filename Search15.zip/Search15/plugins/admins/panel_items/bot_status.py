from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import DONO
from utils import is_bot_online
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

def set_bot_status(status: bool):
    """Define o status do bot para o status definido."""

    cur.execute("UPDATE bot_config SET is_on = ? WHERE ROWID = 0", (status,))
    db.commit()


@Client.on_callback_query(filters.regex("^bot_status$"))
async def bot_status(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    is_on = is_bot_online()

    status = "✅ on" if is_on else "❌ off"
    reverse = "❌ off" if is_on else "✅ on"

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    reverse, callback_data="change_status " + reverse.split()[-1]
                ),
            ],
            [InlineKeyboardButton("🔙 Voltar", callback_data="painel")],
        ]
    )

    await m.edit_message_text(
        f"<b>🚦 Status do bot: </b>\n"
        "<i>- Esta opção controla se o bot responderá a requisições feitas por usuários comuns (não admins) ou não.</i>\n\n"
        f"<b>Status atual:</b> {status}",
        reply_markup=kb,
    )


@Client.on_callback_query(
    filters.regex(r"^change_status (?P<status>.+)"))
async def change_status(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    status = m.matches[0]["status"] == "on"

    set_bot_status(status)

    await m.answer(f"✅ O status foi definido para {status}")

    # Directly call the function again to edit callback data after the change.
    await bot_status(c, m)
