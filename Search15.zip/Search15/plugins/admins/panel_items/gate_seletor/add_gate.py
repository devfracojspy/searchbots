from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery)
from gates_manager import GateManager
from config import DONO
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

class Conversa:
    def __init__(self, c: Client, m: CallbackQuery) -> None:
        self.c = c
        self.m = m
        self.condicao = True
        self.dadosUsuario = m.from_user
        self.dialog = []
    
    async def etapa1(self):
        while self.condicao:
            await self.c.send_message(self.dadosUsuario.id, """<b>Envie o nome da gate ou digite "#" para cancelar!</b>""")
            mensagem = await self.c.wait_for_message(self.dadosUsuario.id)
            
            if("#" == mensagem.text):
                self.condicao=False
                self.dialog=[]
                break
            else:
                self.dialog.append(mensagem.text)
                break
    
    async def etapa2(self):
        while self.condicao:
            await self.c.send_message(self.dadosUsuario.id, """<b>Envie o link do checker!</b>""")
            mensagem = await self.c.wait_for_message(self.dadosUsuario.id)
            
            if("#" == mensagem.text):
                self.condicao=False
                self.dialog=[]
                break
            else:
                self.dialog.append(mensagem.text)
                break
    
    async def etapa3(self):
        while self.condicao:
            await self.c.send_message(self.dadosUsuario.id, """<b>Envie o retorno para Aprovada do checker!</b>""")
            mensagem = await self.c.wait_for_message(self.dadosUsuario.id)
            
            if("#" == mensagem.text):
                self.condicao=False
                self.dialog=[]
                break
            else:
                self.dialog.append(mensagem.text)
                break
    
    async def etapa4(self):
        while self.condicao:
            await self.c.send_message(self.dadosUsuario.id, """<b>Envie o retorno para Reprovada do checker!</b>""")
            mensagem = await self.c.wait_for_message(self.dadosUsuario.id)
            
            if("#" == mensagem.text):
                self.condicao=False
                self.dialog=[]
                break
            else:
                self.dialog.append(mensagem.text)
                break
    
    
    async def finalizar(self):
        try:
            dadosChecker = self.dialog
            self.dialog = []

            if(GateManager.add(dadosChecker[0], dadosChecker[1], dadosChecker[2], dadosChecker[3])):
                await self.c.send_message(self.dadosUsuario.id, """<b>Checker adicionado com sucesso!</b>""")
            else:
                await self.c.send_message(self.dadosUsuario.id, """<b>Desculpe, já existe um gate com esse nome!</b>""")
        except:
            await self.c.send_message(self.dadosUsuario.id, """<b>Operação cancelada!</b>""")

@Client.on_callback_query(filters.regex("^AddGateChecker$"))
async def gateConfig(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    conversa = Conversa(c, m)
    await conversa.etapa1()
    await conversa.etapa2()
    await conversa.etapa3()
    await conversa.etapa4()
    await conversa.finalizar()