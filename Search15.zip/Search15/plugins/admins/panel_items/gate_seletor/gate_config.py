from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from config import DONO
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

def botoes():
    return InlineKeyboardMarkup([[InlineKeyboardButton("Selecionar gate do checker", callback_data="SelectGateChecker")], [InlineKeyboardButton("Adicionar gate do checker", callback_data="AddGateChecker")], [InlineKeyboardButton("Remover gate do checker", callback_data="RemoveChecker")]])

@Client.on_message(filters.command("gate"))
async def gateConfig(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    dadosUsuario = m.from_user
    await c.send_message(dadosUsuario.id, "<b>Clique na opção desejada!</b>", reply_markup=botoes())