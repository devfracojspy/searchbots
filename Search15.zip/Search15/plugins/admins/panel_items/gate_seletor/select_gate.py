from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from gates_manager import GateManager
from config import DONO
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

def botoes():
    markup = []
    for gate in GateManager.list():
        markup.append([InlineKeyboardButton(text=gate[0], callback_data=f"SelectGateChecker{gate[0]}")])
    return InlineKeyboardMarkup(markup)

async def textSend(c, id):
    try:
        await c.send_message(id, f"<b>Clique na gate que deseja selecionar!\n\nAtual: </b>{GateManager.getAtual()}", reply_markup=botoes())
    except:
        await c.send_message(id, "<b>Sem gates para selecionar!</b>")

@Client.on_callback_query(filters.regex("^SelectGateChecker"))
async def removeChecker(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    dadosUsuario = m.from_user
    
    try:
        nome = m.data.split("SelectGateChecker")[1]
        nome[1]
        GateManager.set(nome)
        await m.edit_message_text("<b>Gate selecionada com sucesso!</b>")
    except:
        await textSend(c, dadosUsuario.id)