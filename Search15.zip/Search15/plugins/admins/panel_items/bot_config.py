from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from config import DONO
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

OPTIONS = {
    "📷 Trocar img": "main_img",
}


@Client.on_callback_query(filters.regex(r"^bot_config$"))
async def option_edit(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    global OPTIONS

    bts = []
    for k, v in OPTIONS.items():
        bts.append(InlineKeyboardButton(text=k, callback_data=f"edit {v}"))
    orgn = (lambda data, step: [data[x : x + step] for x in range(0, len(data), step)])(
        bts, 2
    )
    orgn.append([InlineKeyboardButton(text="❮❮ Voltar", callback_data="painel")])
    kb = InlineKeyboardMarkup(inline_keyboard=orgn)
    await m.edit_message_text(
        "<b>⚙️| Painel funções secundárias:\n</b>"
        "<b>Aqui vc encontra funções de outras abas de vendas e de futuras que viram!</b>\n\n"
        "<b>@afxtrem7x</b>",
        reply_markup=kb,
    )


@Client.on_callback_query(filters.regex(r"^edit (?P<item>\w+)"))
async def edit_config(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    global OPTIONS
    msg_type = {
        "main_img": "<b>Link da Imagem Inicial </b><i>EX: new_link</i>",
        "support_user": "<b>Novo Usuário para Suporte no bot </b><i>EX: username</i>",
        "channel_user": "<b>Novo canal de Referencia </b><i>EX: user_channel</i>",
        "texto_grupo": "<b>Novo linkndo grupo </b><i>EX: texto_grupo</i>",
        "texto_start": "<b>Novo texto do Start </b><i>EX: texto_start</i>",
        "texto_shop": "<b>Novo texto do Shop </b><i>EX: texto_shop</i>",
        "texto_unitaria": "<b>Novo texto Unitaria </b><i>EX: texto_unitaria</i>",
        "texto_login": "<b>Novo texto do Login </b><i>EX: texto_login</i>",
        "texto_full": "<b>Novo texto do Menu Full </b><i>EX: comore full</i>",
    }

    item = m.matches[0]["item"]

    if item not in list(msg_type):
        return
    await m.message.delete()
    new_arg = await m.message.ask(
        f"<b>para editar o </b> {msg_type[item]} <b>favor mandar apenas o solicitado igualmente o EXEMPLO</b>",
        reply_markup=ForceReply(),
    )
    if new_arg == "/cancel":
        ...
    else:
        nwdata = new_arg.text
        print(nwdata)
        print(item)
        cur.execute(f"UPDATE bot_config SET {item}='{nwdata}'")
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton("❮❮ Voltar", callback_data="painel"),
                ],
            ]
        )
        await m.message.reply_text(
            "<b>✅ Item alterado com sucesso</b>", reply_markup=kb
        )
        save()
