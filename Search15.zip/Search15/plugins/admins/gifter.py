import random
import string

from pyrogram import Client, filters
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
    Message,
)

from config import PRIVADO, DONO, GIFTERS
from database import cur, save, db
import sqlite3

# Função para verificar se o usuário é o DONO ou está na lista de administradores
def is_admin(user_id: int, cur: sqlite3.Cursor) -> bool:
    # Verifica se o user_id está na lista de IDs de dono definidos no config
    if user_id in DONO:
        return True
    # Se não for um dos donos, verifica se o user_id está na tabela admins do banco de dados
    else:
        # Executa a consulta SQL para verificar se o user_id está na tabela admins
        cur.execute("SELECT COUNT(*) FROM admins WHERE id = ?", [user_id])
        # Retorna True se o user_id estiver na tabela admins, False caso contrário
        return cur.fetchone()[0] > 0

def gift_generator(size=12, chars=string.ascii_uppercase + string.digits):
    return "".join(random.choices(chars, k=size))


GIFT_MSG = """<b>🏷 Gift Card criado:</b>
<b>💰 Valor: R$ {value}</b>
<b>📥 Resgate: </b><code>/resgatar {gift}</code>"""


@Client.on_message(
    filters.regex(r"^/gift (?P<value>-?\d+)"))
async def create_gift(c: Client, m: Message):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    value = int(m.matches[0]["value"])
    gift = gift_generator()

    cur.execute("INSERT INTO gifts(token, value) VALUES(?, ?)", [gift, value])
    save()

    await m.reply_text(
        GIFT_MSG.format(value=value, gift=gift, bot_username=c.me.username)
    )

    text = f"🎁 {m.from_user.first_name} criou um gift card de <b>R${value}</b>\n- Gift card: <code>{gift}</code>"
    return await c.send_message(PRIVADO, text)


@Client.on_inline_query(
    filters.regex(r"^gift (?P<value>-?\d+)"))
async def create_gift_inline(c: Client, m: InlineQuery):
    user_id = m.from_user.id
    if not is_admin(user_id, cur):
        await m.reply_text("Você não é um administrador.")
        return  # Se o usuário não for o dono nem um administrador, não permita o acesso ao painel
    value = int(m.matches[0]["value"])
    gift = gift_generator()

    cur.execute("INSERT INTO gifts(token, value) VALUES(?, ?)", [gift, value])
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("🎁 Resgatar", callback_data="resgatar " + gift)]
        ]
    )

    results = [
        InlineQueryResultArticle(
            title=f"Gift de R$ {value} criado",
            description="Clique para enviar o gift no chat.",
            input_message_content=InputTextMessageContent(
                GIFT_MSG.format(value=value, gift=gift, bot_username=c.me.username)
            ),
            reply_markup=kb,
        )
    ]

    await m.answer(results, cache_time=0, is_personal=True)

    text = f"🎁 {m.from_user.first_name} criou um gift card de <b>R${value}</b>\n- Gift card: <code>{gift}</code>"
    await c.send_message(PRIVADO, text)
