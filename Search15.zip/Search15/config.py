# Bot token.
BOT_TOKEN = "6620681876:AAE201EXhhVjSV1PA72uhMszfjFXrKzwIWc"

API_ID = 9641313
API_HASH = "baefb797b70643121704c7f344b92870"

PRIVADO = -4622093254
PUBLICO = -4622093254
#notifica pix feitos
NOTIFY = -4622093254

WORKERS = 20

# Os administradores podem acessar o painel e adicionar novos materiais ao bot.
DONO = [5760770665, 6596094572]

# Sudoers t�m acesso total ao servidor e podem executar comandos.
SUDOERS = [5760770665, 6596094572]

# All sudoers should be admins too
DONO.extend(SUDOERS)

GIFTERS = []
