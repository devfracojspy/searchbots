import base64
import random
import string
import uuid
from datetime import datetime, timedelta
from typing import Union
import asyncio
import httpx

from database import cur, save
from utils import hc


def names(nms):
    nms = nms.split()
    first_name, last_name = '', ''
    if len(nms) > 1 and len(nms) == 2:
        first_name, last_name = nms[0], nms[1]

    elif len(nms) > 1 and len(nms) == 3:
        first_name, last_name = nms[0], ' '.join(nms[1:])

    elif len(nms) > 1 and len(nms) > 3:
        first_name, last_name = ' '.join(nms[0:2]), ' '.join(nms[2:])

    return first_name, last_name


def get_txid():
    lista = string.ascii_lowercase + string.digits
    txid = ''.join(random.choices(lista, k=35))
    return txid


def two_case(num: Union[int, float]) -> str:
    return format(float(num), '.2f')


def expire_date_mp(time: int = 'minutes') -> str:
    sum_time = timedelta(minutes=time)
    max_time = (datetime.now() + sum_time).astimezone().isoformat()
    expire = '{}.{}{}'.format(
        max_time.split('.')[0],
        max_time.split('.')[1][0:3],
        max_time.split('.')[1][6:],
    )
    return expire


class MercadoPago:
    """Classe para pagamento do Mercado Pago."""

    def __init__(self, access_token: str = 'app_user'):
        self.access_token = access_token
        self.user_id = None
        self.payment_id = None
        self.user_name = None
        self.payment_status = None
        self.value = None
        self.c = 'MercadoPago'

    async def create_payment(
        self,
        value,
        email,
        full_name,
        cpf: str,
        user_id: int = 'telegran user_id',
        time: int = 30,
    ):
        expire = expire_date_mp(time)
        self.user_id = user_id
        # frist_name, last_name = names(full_name)
        payment = await hc.post(
            'https://api.mercadopago.com/v1/payments',
            headers={'Authorization': f'Bearer {self.access_token}'},
            json={
                'transaction_amount': float(value),
                'description': 'saldo',
                'payment_method_id': 'pix',
                'payer': {
                    'email': email,
                    # "first_name": frist_name,
                    # "last_name": last_name,
                    'identification': {'type': 'CPF', 'number': cpf},
                    'address': {},
                },
                'date_of_expiration': expire,
            },
        )

        rjson: dict = payment.json()

        self.payment_id = rjson.get('id')

        self.user_name = full_name
        # pprint(rjson)
        rt = {
            'payment_id': rjson.get('id'),
            'copy_paste': rjson.get('point_of_interaction')
            .get('transaction_data')
            .get('qr_code'),
            'qr_code': rjson.get('point_of_interaction')
            .get('transaction_data')
            .get('qr_code_base64'),
            'status': rjson.get('status'),
        }
        return rt

    async def verify(self):
        rtr = await hc.get(
            f'https://api.mercadopago.com/v1/payments/{self.payment_id}',
            headers={'Authorization': f'Bearer {self.access_token}'},
        )

        getpay = rtr.json()

        rt = {
            'status': getpay.get('status'),
            'payer': {'user_name': self.user_name, 'user_id': self.user_id},
            'value': self.value,
        }

        if rt['status'] == 'approved':
            self.payment_status = 'PAGO'

        return self.payment_status


class GerencianetCredentials:
    """Class used only to generate access_token."""

    def __init__(self, client_id, client_secret, key, cert):
        self.payload = {'grant_type': 'client_credentials'}

        self.client_id = client_id
        self.client_secret = client_secret

        self.cert = cert
        self.key_pix = key
        timeout = httpx.Timeout(40, pool=None)
        self.hc = httpx.AsyncClient(cert=self.cert, timeout=timeout)

    async def token(self):
        rt = await self.hc.post(
            'https://api-pix.gerencianet.com.br/oauth/token',
            auth=(self.client_id, self.client_secret),
            json=self.payload,
        )
        rjson: dict = rt.json()
        return rjson.get('access_token')


class Gerencianet:
    """Classe para pagamento do Gerencianet."""

    def __init__(self, credentials: GerencianetCredentials):
        self.header = {}
        self.credentials = credentials
        self.cert = credentials.cert
        self.payment_id = None
        self.status_payment = None
        self.key_pix = credentials.key_pix
        self.user_id = None
        self.hc = credentials.hc
        self.c = 'GerenciaNet'

    async def create_payment(
        self,
        value: Union[int, float] = 'digito',
        time: int = 'segundos',
        cpf: str = 'cpf sem pontuaÃ§Ã£o',
        name: str = 'nome completo',
        user_id: int = 'user_id',
    ):
        token = await self.credentials.token()
        header = {
            'Authorization': f'Bearer {token}',
        }
        payload = {
            'calendario': {'expiracao': time},
            # "devedor": {"cpf": cpf, "nome": name},
            'valor': {'original': two_case(value)},
            'chave': self.key_pix,
            'solicitacaoPagador': 'Informe o nÃºmero ou identificador do pedido.',
        }
        self.header = header
        dados = await self.hc.post(
            'https://api-pix.gerencianet.com.br/v2/cob',
            headers=header,
            json=payload,
        )
        djson = dados.json()
        ID = djson['loc']['id']
        ########################  QRCODE AND COPY PAST PIX ########################################
        url = f'https://api-pix.gerencianet.com.br/v2/loc/{ID}/qrcode'
        rt = await self.hc.get(url, headers=header)

        self.payment_id = djson['txid']
        self.user_id = user_id

        rjson = rt.json()

        return rjson

    async def verify(self):
        url = f'https://api-pix.gerencianet.com.br/v2/cob/{self.payment_id}'  # https://qrcodes-pix.gerencianet.com.br/v2/
        response = await self.hc.get(url, headers=self.header)

        rjson = response.json()

        if rjson['status'].upper() == 'CONCLUIDA':
            self.status_payment = 'PAGO'

        return self.status_payment


class PagBankCredentials:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        key_pix: str,
        path_pem: str,
        path_key: str,
    ):
        self.client_id = client_id
        self.client_secret = client_secret
        self.key_pix = key_pix
        self.path_pem = path_pem
        self.path_key = path_key
        self.hc = None
        self.headers = None

    async def gerar_tk(self):
        timeout = httpx.Timeout(40, pool=None)
        self.hc = httpx.AsyncClient(
            cert=(self.path_pem, self.path_key), timeout=timeout
        )
        ac_token = cur.execute(
            'SELECT bearer_tk FROM tokens WHERE type_token = ?', ['pagbank']
        ).fetchone()[0]

        if ac_token and ac_token != 'None':
            return ac_token

        url = 'https://secure.api.pagseguro.com/pix/oauth2'

        payload = {
            'grant_type': 'client_credentials',
            'scope': 'pix.write pix.read payloadlocation.write payloadlocation.read cob.write cob.read',
        }

        gerar = await self.hc.post(
            url, auth=(self.client_id, self.client_secret), json=payload
        )
        rt = gerar.json()['access_token']
        cur.execute(
            'UPDATE tokens SET bearer_tk = ? WHERE type_token = ?',
            [rt, 'pagbank'],
        )
        save()
        return rt


class PagBank:
    def __init__(self, credentials: PagBankCredentials):
        self.user_id = None
        self.status_payment = None
        self.headers = None
        self.key_pix = credentials.key_pix
        self.txid = get_txid()
        self.hc = credentials.hc
        self.credentials = credentials
        self.c = 'PagBank'

    async def create_payment(self, value, cpf, name, user_id, time):
        self.user_id = user_id
        self.txid = get_txid()
        token = await self.credentials.gerar_tk()

        url = f'https://secure.api.pagseguro.com/instant-payments/cob/{self.txid}'

        self.headers = {'Authorization': f'Bearer {token}'}

        payload = {
            'calendario': {'expiracao': time},
            # "devedor": {"cpf": cpf, "nome": name},
            'valor': {'original': two_case(value)},
            'chave': self.key_pix,
            'solicitacaoPagador': 'Compra de saldo',
        }

        rt = await self.hc.put(url, headers=self.headers, json=payload)
        return rt.json()

    async def verify(self):
        rt = await self.hc.get(
            f'https://secure.api.pagseguro.com/instant-payments/cob/{self.txid}?revisao=0',
            headers=self.headers,
        )

        rjson = rt.json()

        if rjson['status'] == 'CONCLUIDA':
            self.status_payment = 'PAGO'
            await self.hc.aclose()
        return self.status_payment


class JunoCredentials:
    def __init__(self, client_id, client_secret, key_pix, priv_token):
        self.auth = base64.b64encode(
            (f'{client_id}:{client_secret}').encode()
        ).decode()
        self.priv_token = priv_token
        self.key_pix = key_pix

    async def Acess_token(self):
        auth_tk = await hc.post(
            url='https://api.juno.com.br/authorization-server/oauth/token',
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': f'Basic {self.auth}',
            },
            data={'grant_type': 'client_credentials'},
        )
        return auth_tk.json()['access_token']


class Juno:
    def __init__(self, objeto: JunoCredentials):
        self.payment_id = None
        self.status_payment = None
        self.user_id = None
        self.key_pix = objeto.key_pix
        self.auth = objeto.auth
        self.priv_token = objeto.priv_token
        self.objs = objeto
        self.txid = get_txid()
        self.headers = None
        self.c = 'Juno'

    async def create_payment(
        self,
        value: Union[int, float] = 'digito',
        time: int = 300,
        cpf: str = 'cpf sem pontuaÃ§Ã£o',
        name: str = 'nome completo',
        user_id: int = 'user_id',
    ):

        self.user_id = user_id
        self.txid = get_txid()
        dados_cob = {
            'calendario': {'expiracao': time},
            # "devedor": {"cpf": cpf, "nome": name},
            'valor': {'original': two_case(value)},
            'chave': self.key_pix,
            'solicitacaoPagador': 'ServiÃ§o realizado.',
        }

        access_token = await self.objs.Acess_token()

        self.headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json',
            'X-Api-Version': '2',
            'X-Resource-Token': self.priv_token,
            'X-Idempotency-Key': str(uuid.uuid4()).upper(),
        }

        cob_imediata = await hc.put(
            url=f'https://api.juno.com.br/pix-api/v2/cob/{self.txid}',
            headers=self.headers,
            json=dados_cob,
        )
        qr_code = await hc.get(
            f'https://api.juno.com.br/pix-api/qrcode/v2/{self.txid}',
            headers=self.headers,
        )
        return base64.b64decode(qr_code.json()['qrcodeBase64']).decode()

    async def verify(self):
        rt = await hc.get(
            f'https://api.juno.com.br/pix-api/v2/cob/{self.txid}',
            headers=self.headers,
        )
        self.status_payment = (
            'PAGO' if rt.json()['status'] == 'CONCLUIDA' else None
        )
        return self.status_payment


class Asaas:
    def __init__(self, access_token: str = 'Acess_token'):
        self.access_token = access_token
        self.user_id = None
        self.payment_id = None
        self.user_name = None
        self.payment_status = None
        self.value = None
        self.c = 'Asaas'

    async def add_to_client(self, name: str, doc: str, user_id: int) -> dict:
        add_client = await hc.post(
            url='https://www.asaas.com/api/v3/customers',
            headers={
                'Content-Type': 'application/json',
                'access_token': self.access_token,
            },
            json=dict(name=name, cpfCnpj=doc),
        )
        try:
            custumer_id = add_client.json()['id']
            cur.execute(
                'UPDATE users SET customer_id = ? WHERE id=?',
                [custumer_id, user_id],
            )
            save()
            return custumer_id
        except:
            return {}

    async def create_cob(
        self, customer_id: str, value: float | int, desc: str, user_id: int
    ) -> dict:
        self.value = value
        self.user_id = user_id

        get_pix = await hc.post(
            url='https://www.asaas.com/api/v3/payments',
            headers={
                'Content-Type': 'application/json',
                'access_token': self.access_token,
            },
            json={
                'customer': customer_id,
                'billingType': 'PIX',
                'dueDate': (datetime.now() + timedelta(minutes=5)).strftime(
                    '%Y-%m-%d %H:%M:%S'
                ),
                'value': value,
                'description': desc,
                'postalService': False,
            },
        )
        try:
            self.payment_id = get_pix.json()['id']
            return self.payment_id
        except:
            return {}

    async def get_QRcode(self) -> dict:
        get_qr = await hc.get(
            url=f'https://www.asaas.com/api/v3/payments/{self.payment_id}/pixQrCode',
            headers={
                'Content-Type': 'application/json',
                'access_token': self.access_token,
            },
        )
        return get_qr.json()['payload']

    async def verify(self):
        get_status = await hc.get(
            url=f'https://www.asaas.com/api/v3/payments/{self.payment_id}',
            headers={
                'Content-Type': 'application/json',
                'access_token': self.access_token,
            },
        )
        self.payment_status = (
            'PAGO' if get_status.json()['status'] == 'RECEIVED' else None
        )
        return self.payment_status


class OpenPix:
    def __init__(self, access_token: str):
        self.access_token = access_token
        self.headers = {
            "content-type": "application/json",
            "Authorization": self.access_token
        }
        self.user_id = None
        self.payment_id = None
        self.user_name = None
        self.payment_status = None
        self.value = None
        self.c = 'OpenPix'
        self.status = None

    async def create_customer(self, name: str):
        send = await hc.post(
            url="https://api.openpix.com.br/api/openpix/v1/customer",

            headers=self.headers,

            json={
                "Customer": {
                    "name": "Dan van helsing",
                    "taxID": "31324227036",
                    "email": "email0@example.com",
                    "phone": "5511999999999",
                    "correlationID": "9134e286-6f71-427a-bf00-241681624586"
                }
            })
        return send.json()

    async def create_cob(self, value: int, user_id: int):
        self.user_id = user_id
        cob = await hc.post(
            url="https://api.openpix.com.br/api/openpix/v1/charge",
            headers=self.headers,
            json={
                "correlationID": f"{uuid.uuid4()}",
                "value": value,
                "comment": "good",
                "expiresIn": 900,
            }
        )
        response = cob.json()
        self.payment_id = response["charge"]["globalID"]
        return response["brCode"]

    async def verify(self):
        status = await hc.get(
            headers=self.headers,
            url="https://api.openpix.com.br/api/openpix/v1/charge/" + self.payment_id
        )
        self.status = "PAGO" if status.json()["charge"]["status"] == "COMPLETED" else None
        return self.status


import sqlite3
import httpx

class EasyPix:
    def __init__(self):
        # Estabelecendo conexão com o banco de dados
        conn = sqlite3.connect('main.db')  # Nome do banco de dados
        cur = conn.cursor()  # Criando o cursor
        
        result = cur.execute(
            "SELECT client_secret FROM tokens WHERE type_token = ?",
            ["easy"]
        ).fetchone()

        if result:
            self.access_token = result[0]
        else:
            raise ValueError("Access token not found for easy")

        conn.close()  # Fechar a conexão após o uso

        # Inicializando outras variáveis
        self.user_id = None
        self.payment_id = None
        self.user_name = None
        self.payment_status = None
        self.value = None
        self.c = "easy"

    async def create_payment(self, value: float, uid: int, cpf):
        self.user_id = uid

        # Converter o valor para o formato desejado
        formatted_value = '{:.2f}'.format(value)

        # Atualizando a URL para criar o PIX conforme a nova API
        url = f"https://easy-pix.com/createPix?apiKey={self.access_token}&value={formatted_value}&user_id={uid}&cpf={cpf}"

        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            data = response.json()

        self.payment_id = data.get("pixId")
        return data.get("code")

    async def verify(self):
        # Atualizando a URL para consultar o status do PIX conforme a nova API
        url = f"https://easy-pix.com/pix/{self.payment_id}?apiKey={self.access_token}"

        async with httpx.AsyncClient() as client:
            response = await client.get(url)

        json_data = response.json()  # Guardar a resposta JSON

        print(response.text)  # Para depuração

        status = json_data.get("status")
        
        # Verificando o status do pagamento
        if status == "verified":
            self.payment_status = "PAGO"
        return "PAGO" if status == "verified" else None
      
import httpx  
import json
import base64
from io import BytesIO
from PIL import Image

class SampaBank:
    def __init__(self, max_retries=5):
        self.access_token = cur.execute(
            "select client_secret from tokens where type_token = ?",
            ["sampa"]
        ).fetchone()[0]
        self.user_id = None
        self.payment_id = None
        self.user_name = None
        self.payment_status = None
        self.value = None
        self.c = "sampa"
        self.max_retries = max_retries 

    async def create_payment(self, value: float, uid: int):
        self.user_id = uid
        value = int(value * 100) 


        data = await hc.post(
            url="https://api.sampabank.com/api/pix/gerar/",
            headers={"Authorization": f"Bearer {self.access_token}"},
            json={"amount": value}
        )

        print("Resposta da API (criaÃ§Ã£o de pagamento):", data.text)

        if data.status_code == 200:
            try:
                response_json = data.json()
                self.payment_id = response_json.get("id")
                copiaecola = response_json.get("copiaecola")
                qrcode_base64 = response_json.get("qrcode_base64")
                
            
                if copiaecola:
                    print("CÃ³digo PIX (copia e cola):", copiaecola.strip())
                else:
                    print("CÃ³digo 'copia e cola' nÃ£o encontrado.")
                
       
                if qrcode_base64:
                    image_data = base64.b64decode(qrcode_base64)
                    image = Image.open(BytesIO(image_data))
                    image.show()  
                return copiaecola.strip() 
            except json.JSONDecodeError:
                print("Erro ao decodificar JSON:", data.text)
        else:
            print("Erro na criaÃ§Ã£o do pagamento:", data.status_code, data.text)
            
    async def verify(self):
        retries = 0
        while retries < self.max_retries:
    
            async with httpx.AsyncClient() as hc:
                response = await hc.post(
                    url="https://api.sampabank.com/api/pix/consultar/",
                    headers={"Authorization": f"Bearer {self.access_token}"},
                    json={"trxid": self.payment_id}
                )

            print("Resposta da API (verificaÃ§Ã£o de pagamento):", response.text)

            if response.status_code == 200:
                try:
                    response_json = response.json()
                    if response_json.get("status") == "pid":
                        self.payment_status = "PAGO"
                        print("Pagamento aprovado!")
                        break
                    else:
                        self.payment_status = "PENDENTE"
                        print("Pagamento pendente. Verificando novamente...")
                except json.JSONDecodeError:
                    print("Erro ao decodificar JSON:", response.text)
            else:
                print("Erro na verificaÃ§Ã£o de pagamento:", response.status_code, response.text)

            retries += 1
            await asyncio.sleep(10)

        if self.payment_status == "PENDENTE":
            print("O pagamento nÃ£o foi aprovado apÃ³s vÃ¡rias tentativas.")
        return self.payment_status



AUTO_PAYMENTS = {
    'mercado pago': MercadoPago,
    'gerencia net': Gerencianet,
    'pagbank': PagBank,
    'juno': Juno,
    'asaas': Asaas,
    'open pix': OpenPix,
    'easy': EasyPix,
    'sampa': SampaBank
}